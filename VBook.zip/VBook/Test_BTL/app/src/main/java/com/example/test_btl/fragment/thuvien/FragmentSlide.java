package com.example.test_btl.fragment.thuvien;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.example.test_btl.R;
import com.example.test_btl.adapter.thuvien.SlideAdapter;
import com.example.test_btl.model.Slide;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;

import java.util.ArrayList;
import java.util.List;

import me.relex.circleindicator.CircleIndicator;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentSlide extends Fragment {

    private View view;
    private ViewPager viewPager;
    private CircleIndicator circleIndicator;
    private SlideAdapter slideAdapter;
    private Runnable runnable;
    private Handler handler;
    private int currentItem = -1;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            view = inflater.inflate(R.layout.fragment_slide, container, false);
            anhXa();
            getData();
            return view;
    }

    private void anhXa(){
        viewPager = view.findViewById(R.id.viewpager);
        circleIndicator = view.findViewById(R.id.indicatorBannerHome);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private void getData() {
        Dataservice dataservice = APIService.getService();
        Call<List<Slide>> callback = dataservice.GetDataBanner();

        callback.enqueue(new Callback<List<Slide>>() {
            @Override
            public void onResponse(Call<List<Slide>> call, Response<List<Slide>> response) {
                ArrayList<Slide> banners = (ArrayList<Slide>) response.body();
                slideAdapter = new SlideAdapter(getActivity(),banners);
                viewPager.setAdapter(slideAdapter);
                circleIndicator.setViewPager(viewPager);
                handler = new Handler();
                runnable = new Runnable() {
                    @Override
                    public void run() {
                        currentItem = viewPager.getCurrentItem();
                        currentItem++ ;
                        if(currentItem >= 4 ){
                            currentItem = 0;
                        }
                        viewPager.setCurrentItem(currentItem
                                ,true);
                        handler.postDelayed(runnable,4500);
                    }
                };
                handler.postDelayed(runnable,4500);
            }

            @Override
            public void onFailure(Call<List<Slide>> call, Throwable t) {
            }
        });
    }
}
