package com.example.test_btl.fragment.thuvien;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.example.test_btl.R;
import com.example.test_btl.adapter.thuvien.TheloaiAdapter;
import com.example.test_btl.model.TheLoai;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentTablayoutTheloai extends Fragment {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private TextView txtTieuDe;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_category_viewpager,container,false);
        tabLayout = view.findViewById(R.id.myTabLayout);
        viewPager = view.findViewById(R.id.myViewPage);
        txtTieuDe = view.findViewById(R.id.tieude_category);
        txtTieuDe.setText("Thể Loại");
        getData();
        return view;
    }

    private void getData(){
        Dataservice dataservice = APIService.getService();
        TheloaiAdapter adapter = new TheloaiAdapter(getActivity().getSupportFragmentManager());
        Call<List<TheLoai>> callTitle = dataservice.GetDataCategory();
        callTitle.enqueue(new Callback<List<TheLoai>>() {
            @Override
            public void onResponse(Call<List<TheLoai>> call, Response<List<TheLoai>> response) {
                ArrayList<TheLoai> listCategory = (ArrayList<TheLoai>) response.body();
                adapter.setCategories(listCategory);
                viewPager.setAdapter(adapter);
                tabLayout.setupWithViewPager(viewPager);
            }
            @Override
            public void onFailure(Call<List<TheLoai>> call, Throwable t) {
            }
        });
    }

}
