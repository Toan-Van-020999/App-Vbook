package com.example.test_btl.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.test_btl.R;
import com.example.test_btl.adapter.thuvien.BinhLuanAdapter;
import com.example.test_btl.model.BinhLuan;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BinhLuanActivity extends AppCompatActivity implements View.OnClickListener{
    private String iduser,id_truyen;
    private EditText edtCmt;
    private TextView txtaddcmt;
    private CircleImageView circleImageView;
    private RecyclerView rcv;
    private Dataservice dataservice = APIService.getService();
    private SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_binhluan);
        sp = getApplicationContext().getSharedPreferences("dataUser", Context.MODE_PRIVATE);

        anhxa();

        Picasso.with(BinhLuanActivity.this).load("http://192.168.1.197/btl_mobile/" + sp.getString("image","")).into(circleImageView);
        iduser = getIntent().getStringExtra("iduser");
        id_truyen = getIntent().getStringExtra("idtale");
        getDataComment();
        txtaddcmt.setOnClickListener(this);
    }

    private void anhxa() {
        edtCmt = findViewById(R.id.edtaddcmt);
        txtaddcmt = findViewById(R.id.postCmt);
        rcv = findViewById(R.id.rcvBinhLuan);
        circleImageView = findViewById(R.id.imgUserCmtt);
    }

    private void getDataComment() {
        dataservice = APIService.getService();
        Call<List<BinhLuan>> callback = dataservice.GetDataComment(id_truyen);
        callback.enqueue(new Callback<List<BinhLuan>>() {
            @Override
            public void onResponse(Call<List<BinhLuan>> call, Response<List<BinhLuan>> response) {
                ArrayList<BinhLuan> list = (ArrayList<BinhLuan>) response.body();
                BinhLuanAdapter adapter = new BinhLuanAdapter(BinhLuanActivity.this,R.layout.dong_binhluan,list);
                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(BinhLuanActivity.this);
                linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                rcv.setLayoutManager(linearLayoutManager);
                rcv.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<BinhLuan>> call, Throwable t) {

            }
        });
    }

    private  void updateCmtToDataBase(){
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dinhdang = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");
        dataservice = APIService.getService();
        if (edtCmt.getText().toString().trim() == null || edtCmt.getText().toString().trim().isEmpty()){
            Toast.makeText(BinhLuanActivity.this,"Bạn chưa nhập bình luận",Toast.LENGTH_SHORT).show();
        }else {
            Call<String> str = dataservice.UpdateComment(iduser, id_truyen, edtCmt.getText().toString().trim(), dinhdang.format(calendar.getTime()));
            str.enqueue(new Callback<String>() {
                @Override
                public void onResponse(Call<String> call, Response<String> response) {
                }
                @Override
                public void onFailure(Call<String> call, Throwable t) {
//                    Log.d("d", t.getMessage());
                }
            });
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            getDataComment();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.postCmt:
                updateCmtToDataBase();
                edtCmt.setText("");
                break;
        }
    }
}