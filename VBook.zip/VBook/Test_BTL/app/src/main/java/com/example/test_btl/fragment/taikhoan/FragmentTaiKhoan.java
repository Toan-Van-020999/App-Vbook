package com.example.test_btl.fragment.taikhoan;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.test_btl.R;
import com.example.test_btl.activity.DangNhapActivity;
import com.example.test_btl.activity.TruyenActivity;
import com.example.test_btl.activity.TruyenTuongTacActivity;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;
import com.squareup.picasso.Picasso;
//import com.gun0912.tedpermission.PermissionListener;
//import com.gun0912.tedpermission.TedPermission;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;


public class FragmentTaiKhoan extends Fragment implements View.OnClickListener {

    private SharedPreferences sp;
    private TextView txtUserName;
    private RelativeLayout rlldangxuat;
    private CircleImageView img;
    private RelativeLayout rltruyendadang,rltruyendayeuthich,rltruyendabinhluan,rlchinhsach,rlvechungtoi,rlemail,rlcaidat;
    private Dataservice dataservice = APIService.getService();
    private View view;
    private int IMG_REQUEST = 21;
    private Bitmap bitmap;
    private APIService apiService1 = new APIService();
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            view = inflater.inflate(R.layout.fragment_account, container, false);
            anhxa();
            sp = getActivity().getSharedPreferences("dataUser", Context.MODE_PRIVATE);
            txtUserName.setText(sp.getString("taikhoan", ""));
//            Toast.makeText(getActivity(),"check",Toast.LENGTH_SHORT).show();

            Picasso.with(getActivity()).load("http://192.168.1.197/btl_mobile/" + sp.getString("image", "")).into(img);
            img.setOnClickListener(this);
            rlldangxuat.setOnClickListener(this);
            rltruyendayeuthich.setOnClickListener(this);
            rltruyendadang.setOnClickListener(this);
            rltruyendabinhluan.setOnClickListener(this);
            rlchinhsach.setOnClickListener(this);
            rlvechungtoi.setOnClickListener(this);
            rlemail.setOnClickListener(this);
            rlcaidat.setOnClickListener(this);

        return  view;
    }

    private void anhxa() {
        rlcaidat = view.findViewById(R.id.rlcaidat);
        rlvechungtoi = view.findViewById(R.id.vechungtoi);
        rlldangxuat = view.findViewById(R.id.rllDangXuat);
        txtUserName = view.findViewById(R.id.txtnameAccount);
        img = view.findViewById(R.id.imgAccount);
        rltruyendadang = view.findViewById(R.id.rltruyendadang);
        rltruyendayeuthich = view.findViewById(R.id.rltruyendayeuthich);
        rltruyendabinhluan = view.findViewById(R.id.rltruyendabinhluan);
        rlchinhsach = view.findViewById(R.id.rlchinhsach);
        rlemail = view.findViewById(R.id.rlemail);
    }
    @Override
    public void onClick(View v) {
        Intent intent = new Intent(getActivity(), TruyenTuongTacActivity.class);
        switch (v.getId()){
            case R.id.rllDangXuat:
                confirmLogout();
                break;
            case R.id.vechungtoi:
                intent.putExtra("key","vechungtoi");
                startActivity(intent);
                break;
            case R.id.rltruyendadang:
                intent.putExtra("key","truyendadang");
                startActivity(intent);
                break;
            case R.id.rltruyendayeuthich:
                intent.putExtra("key","truyendayeuthich");
                startActivity(intent);
                break;
            case R.id.rltruyendabinhluan:
                intent.putExtra("key","truyendabinhluan");
                startActivity(intent);
                break;
            case R.id.rlchinhsach:
                intent.putExtra("key","chinhsach");
                startActivity(intent);
                break;
            case R.id.imgAccount:
                uploadImage();
                break;
            case R.id.rlcaidat:
//                xacNhan();
                break;
            case R.id.rlemail:
                sendEmail();
                break;
        }
    }

    private void sendEmail() {
        String str = "toanvan020999@gmail.com";
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mail too:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL,new String[]{str});
        startActivity(Intent.createChooser(emailIntent,"Choose an Email Client"));
    }


    private void uploadImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, IMG_REQUEST);
    }


    private void xacNhan(){
        Dataservice dataservice = APIService.getService();
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,75, byteArrayOutputStream);
        byte[] imageInByte = byteArrayOutputStream.toByteArray();
        String encodedImage =  Base64.encodeToString(imageInByte,Base64.DEFAULT);

        Call<String> call = dataservice.uploadImage(encodedImage,sp.getString("idUser",""));
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {

            }
            @Override
            public void onFailure(Call<String> call, Throwable t) {
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == IMG_REQUEST && resultCode == RESULT_OK && data != null){
            Uri path = data.getData();

            try {
                bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(),path);
                img.setImageBitmap(bitmap);
                Picasso.with(getActivity()).load(path).into(img);
                xacNhan();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    private void confirmLogout(){
        AlertDialog.Builder alBuilder = new AlertDialog.Builder(getActivity());
        alBuilder.setTitle("Cảnh báo");
        alBuilder.setMessage("Bạn chắc chắn muốn đăng xuất");
        alBuilder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                SharedPreferences preferences = getActivity().getApplicationContext().getSharedPreferences("dataUser", Context.MODE_PRIVATE);
                preferences.edit().remove("idUser").commit();
                preferences.edit().remove("taikhoan").commit();
                Intent intent = new Intent(getActivity(), DangNhapActivity.class);
                startActivity(intent);
            }
        });
        alBuilder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                return;
            }
        });
        alBuilder.show();
    }
}
