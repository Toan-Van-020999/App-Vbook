package com.example.test_btl.adapter.thuvien;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.test_btl.R;
import com.example.test_btl.activity.TruyenActivity;
import com.example.test_btl.model.Truyen;

import java.util.ArrayList;

public class TruyenMoiCapNhatAdapter extends RecyclerView.Adapter<TruyenMoiCapNhatAdapter.ViewHolder> {
    private Context context;
    private ArrayList<Truyen> listNewTale ;

    public TruyenMoiCapNhatAdapter(Context context, ArrayList<Truyen> listNewTale) {
        this.context = context;
        this.listNewTale = listNewTale;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater =LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.dong_truyenmoicapnhat,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Truyen truyen = listNewTale.get(position);
        holder.ten.setText(truyen.getTen());
        Glide.with(context).load(truyen.getAnh()).into(holder.img);
    }

    @Override
    public int getItemCount() {
        return listNewTale.size();
    }

    public  class  ViewHolder extends RecyclerView.ViewHolder{
        ImageView img;
        TextView ten;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.imageviewnewcomic);
            ten = itemView.findViewById(R.id.textviewcomic);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, TruyenActivity.class);
                    intent.putExtra("thongtintruyen",listNewTale.get(getPosition()));
                    context.startActivity(intent);
                }
            });
        }
    }
}
