package com.example.test_btl.adapter.thuvien;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.test_btl.R;
import com.example.test_btl.model.BinhLuan;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class BinhLuanAdapter extends RecyclerView.Adapter<BinhLuanAdapter.Viewholder>{

    private Context context;
    private int layout;
    private ArrayList<BinhLuan> list;

    public BinhLuanAdapter(Context context, int layout, ArrayList<BinhLuan> list) {
        this.context = context;
        this.layout = layout;
        this.list = list;
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(layout,parent,false);
        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, int position) {
        BinhLuan binhLuan = list.get(position);
        holder.cmt.setText(binhLuan.getNoidung());
        holder.thoigian.setText(binhLuan.getThoigian());
        holder.username.setText(binhLuan.getTaikhoan());
//        holder.imgUser.setImageResource();
        Picasso.with(context).load("http://192.168.1.197/btl_mobile/" + binhLuan.getImage()).into(holder.imgUser);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public  class  Viewholder extends RecyclerView.ViewHolder{
        public ImageView imgUser;
        public TextView username,cmt,thoigian;
        public Viewholder(@NonNull View itemView) {
            super(itemView);
            imgUser = itemView.findViewById(R.id.imgUserdongcmt);
            username = itemView.findViewById(R.id.username);
            cmt = itemView.findViewById(R.id.cmt);
            thoigian= itemView.findViewById(R.id.thoigian);
        }
    }



}
