package com.example.test_btl.adapter.thuvien;

import android.os.Bundle;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.test_btl.fragment.thuvien.FragmentViewpagerXephang;

import java.util.ArrayList;

public class XephangAdapter extends FragmentPagerAdapter {
    private ArrayList<String> listTitle = new ArrayList<>();

    public XephangAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        Bundle data = new Bundle();
        data.putString("title",listTitle.get(position));
        Fragment fragment = new FragmentViewpagerXephang();
        fragment.setArguments(data);//set data cho fragments.
        return fragment;
    }

    @Override
    public int getCount() {
        return listTitle.size();
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return listTitle.get(position);
    }

    public void setTitle(ArrayList<String> listTitle){
        this.listTitle = listTitle;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        return;
    }

}
