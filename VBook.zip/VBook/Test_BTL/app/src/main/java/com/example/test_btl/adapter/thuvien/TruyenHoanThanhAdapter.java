    package com.example.test_btl.adapter.thuvien;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.test_btl.R;
import com.example.test_btl.activity.TruyenActivity;
import com.example.test_btl.model.Truyen;

import java.util.ArrayList;

public class TruyenHoanThanhAdapter extends RecyclerView.Adapter<TruyenHoanThanhAdapter.Viewholder> {
    private Context context;
    private ArrayList<Truyen> arrayList;

    public TruyenHoanThanhAdapter(Context context, ArrayList<Truyen> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }



    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.dong_truyenhoanthanh,parent,false);
        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, int position) {
        Truyen truyen = arrayList.get(position);
        holder.name.setText(truyen.getTen());
        Glide.with(context).load(truyen.getAnh()).into(holder.img);
    }

    @Override
    public int getItemCount() {
        return arrayList == null ? 0 : arrayList.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder{

        ImageView img;
        TextView name;
        public Viewholder(@NonNull View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.imgcomicfinish);
            name = itemView.findViewById(R.id.txtcomicfinish);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, TruyenActivity.class);
                    intent.putExtra("thongtintruyen",arrayList.get(getPosition()));
                    context.startActivity(intent);
                }
            });
        }
    }
}
