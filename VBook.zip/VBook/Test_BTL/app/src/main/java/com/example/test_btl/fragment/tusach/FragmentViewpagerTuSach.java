package com.example.test_btl.fragment.tusach;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.test_btl.R;
import com.example.test_btl.adapter.thuvien.TaleCategoryAdapter;
import com.example.test_btl.model.Truyen;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentViewpagerTuSach extends Fragment {
    private RecyclerView recyclerView;
    private SharedPreferences sp;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_viewpager_tusach,container,false);
        recyclerView = view.findViewById(R.id.rcvbookcase);
        sp = getActivity().getApplicationContext().getSharedPreferences("dataUser", Context.MODE_PRIVATE);
        getData();
        return view;
    }




    private void getData() {
        Dataservice dataservice = APIService.getService();
        Call<List<Truyen>> callback = null;
        String title = getArguments().getString("titlebookcase");
        switch (title){
            case "Đang theo dõi":
                callback = dataservice.GetDataTruyenDangTheoDoi(sp.getString("idUser",""));
                break;
            case "Vừa xem":
                callback = dataservice.GetDataTruyenVuaXem(sp.getString("idUser",""));
                break;

        }
        callback.enqueue(new Callback<List<Truyen>>() {
            @Override
            public void onResponse(Call<List<Truyen>> call, Response<List<Truyen>> response) {
                ArrayList<Truyen> listTale = (ArrayList<Truyen>) response.body();
                TaleCategoryAdapter adapter = new TaleCategoryAdapter(getActivity(),listTale);
                GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity().getApplicationContext(),3, RecyclerView.VERTICAL,false);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(gridLayoutManager);
                recyclerView.setAdapter(adapter);
            }
            @Override
            public void onFailure(Call<List<Truyen>> call, Throwable t) {
            }
        });
    }
}
