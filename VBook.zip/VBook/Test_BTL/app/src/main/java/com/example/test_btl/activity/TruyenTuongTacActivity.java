package com.example.test_btl.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;

import com.example.test_btl.R;
import com.example.test_btl.fragment.taikhoan.FragmentVeChungToi;
import com.example.test_btl.fragment.thuvien.FragmentTruyenBinhLuan;
import com.example.test_btl.fragment.taikhoan.FragmentTruyenYeuThich;
import com.example.test_btl.fragment.taikhoan.FragmentTruyenDaDang;
import com.example.test_btl.fragment.taikhoan.FragmentChinhSach;

public class TruyenTuongTacActivity extends AppCompatActivity {

    private Fragment selectedFragment = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_truyentuongtac);
        Intent intent = getIntent();
        String key = intent.getStringExtra("key");

        switch (key){
            case "truyendadang":
                selectedFragment = new FragmentTruyenDaDang();
                break;
            case "truyendayeuthich":
                selectedFragment = new FragmentTruyenYeuThich();
                break;
            case "truyendabinhluan":
                selectedFragment = new FragmentTruyenBinhLuan();
                break;
            case "chinhsach":
                selectedFragment = new FragmentChinhSach();
                break;
            case "vechungtoi":
                selectedFragment = new FragmentVeChungToi();
                break;
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.frlTalehaveInteracted,selectedFragment).commit();
    }
}