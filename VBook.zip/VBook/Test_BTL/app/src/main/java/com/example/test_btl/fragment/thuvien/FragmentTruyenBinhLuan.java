package com.example.test_btl.fragment.thuvien;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.test_btl.R;
import com.example.test_btl.adapter.thuvien.TaleCategoryAdapter;
import com.example.test_btl.model.Truyen;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentTruyenBinhLuan extends Fragment {
    private RecyclerView rcvTruyenBinhLuan = null;
    private SharedPreferences sp;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_noidung_boloc,container,false);
        rcvTruyenBinhLuan = view.findViewById(R.id.rvc);

        sp = getActivity().getSharedPreferences("dataUser", Context.MODE_PRIVATE);
        getDataTruyenBinhLuan();
        return view;
    }

    private void getDataTruyenBinhLuan() {
        Dataservice dataservice = APIService.getService();
        Call<List<Truyen>> callback = dataservice.GetDataTruyenBinhLuan(sp.getString("idUser",""));
        callback.enqueue(new Callback<List<Truyen>>() {
            @Override
            public void onResponse(Call<List<Truyen>> call, Response<List<Truyen>> response) {
                ArrayList<Truyen> list = (ArrayList<Truyen>) response.body();
                System.out.println(list.size());
                TaleCategoryAdapter adapter = new TaleCategoryAdapter(getActivity(),list);
                GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity().getApplicationContext(),3, RecyclerView.VERTICAL,false);
                rcvTruyenBinhLuan.setHasFixedSize(true);
                rcvTruyenBinhLuan.setLayoutManager(gridLayoutManager);
                rcvTruyenBinhLuan.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<Truyen>> call, Throwable t) {
            }
        });
    }
}
