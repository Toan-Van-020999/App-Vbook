package com.example.test_btl.fragment.thuvien;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.test_btl.R;
import com.example.test_btl.activity.ListTaleActivity;
import com.example.test_btl.adapter.thuvien.TruyenMoiCapNhatAdapter;
import com.example.test_btl.model.Truyen;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentTruyenMoiCapNhat extends Fragment implements View.OnClickListener{
    private View view;
    private RecyclerView recyclerView;
    private TextView txtxemthemNewUpdate;
    private Context context;
    ArrayList<Truyen> list;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            context = getActivity();
            view = inflater.inflate(R.layout.fragment_truyenmoicapnhat, container, false);
            recyclerView = view.findViewById(R.id.recyclerviewnewcomic);
            txtxemthemNewUpdate = view.findViewById(R.id.textviewxemthemcomic);

            getData();
            txtxemthemNewUpdate.setOnClickListener(this);
        return view;
    }



    public void getData() {
        Dataservice dataservice = APIService.getService();
        Call<List<Truyen>> callback = dataservice.GetDataNewTaleUpdate();
        callback.enqueue(new Callback<List<Truyen>>() {
            @Override
            public void onResponse(Call<List<Truyen>> call, Response<List<Truyen>> response) {
                ArrayList<Truyen> listTale = (ArrayList<Truyen>) response.body();
                TruyenMoiCapNhatAdapter adapter =new TruyenMoiCapNhatAdapter(getActivity(),listTale);
                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
                linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
                recyclerView.setLayoutManager(linearLayoutManager);
                recyclerView.setAdapter(adapter);
            }
            @Override
            public void onFailure(Call<List<Truyen>> call, Throwable t) {
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.textviewxemthemcomic:
                SharedPreferences sharedPreferences = context.getSharedPreferences("xemthem", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("search","newtaleupdate");
                editor.apply();
                Intent intent = new Intent(context, ListTaleActivity.class);
                intent.putExtra("more","newtaleupdate");
                startActivity(intent);
                break;

        }
    }
}



