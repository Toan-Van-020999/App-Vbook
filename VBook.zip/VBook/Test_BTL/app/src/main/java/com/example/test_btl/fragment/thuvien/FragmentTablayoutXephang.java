package com.example.test_btl.fragment.thuvien;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.example.test_btl.R;
import com.example.test_btl.adapter.thuvien.XephangAdapter;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class FragmentTablayoutXephang extends Fragment {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private TextView textTieuDe;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_category_viewpager,container,false);
        viewPager = view.findViewById(R.id.myViewPage);
        tabLayout = view.findViewById(R.id.myTabLayout);
        textTieuDe = view.findViewById(R.id.tieude_category);
        ArrayList<String> listTitle = new ArrayList<>();
        listTitle.add("TOP XEM NHIỀU");
        listTitle.add("TOP YÊU THÍCH");
        listTitle.add("TOP THEO DÕI");
        listTitle.add("TOP BÌNH LUẬN");
        textTieuDe.setText("Xếp Hạng");
        XephangAdapter adapter = new XephangAdapter(getActivity().getSupportFragmentManager());
        adapter.setTitle(listTitle);
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
        return view;
    }

}
