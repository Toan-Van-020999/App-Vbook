package com.example.test_btl.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BinhLuan {

    @SerializedName("Id")
    @Expose
    private String id;
    @SerializedName("Iduser")
    @Expose
    private String iduser;
    @SerializedName("Id_truyen")
    @Expose
    private String idTruyen;
    @SerializedName("Noidung")
    @Expose
    private String noidung;
    @SerializedName("Thoigian")
    @Expose
    private String thoigian;
    @SerializedName("Taikhoan")
    @Expose
    private String taikhoan;
    @SerializedName("Image")
    @Expose
    private String image;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIduser() {
        return iduser;
    }

    public void setIduser(String iduser) {
        this.iduser = iduser;
    }

    public String getIdTruyen() {
        return idTruyen;
    }

    public void setIdTruyen(String idTruyen) {
        this.idTruyen = idTruyen;
    }

    public String getNoidung() {
        return noidung;
    }

    public void setNoidung(String noidung) {
        this.noidung = noidung;
    }

    public String getThoigian() {
        return thoigian;
    }

    public void setThoigian(String thoigian) {
        this.thoigian = thoigian;
    }

    public String getTaikhoan() {
        return taikhoan;
    }

    public void setTaikhoan(String taikhoan) {
        this.taikhoan = taikhoan;
    }

}
