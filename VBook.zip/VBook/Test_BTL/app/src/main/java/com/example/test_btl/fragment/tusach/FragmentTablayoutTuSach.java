package com.example.test_btl.fragment.tusach;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.example.test_btl.R;
import com.example.test_btl.adapter.tusach.TuSachAdapter;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class FragmentTablayoutTuSach extends Fragment {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private View view;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view == null) {
            view = inflater.inflate(R.layout.fragment_tusach, container, false);
            tabLayout = view.findViewById(R.id.tabLayoutBookcase);
            viewPager = view.findViewById(R.id.viewPagerBookcase);
            ArrayList<String> listTitle = new ArrayList<>();
            listTitle.add("Đang theo dõi");
            listTitle.add("Vừa xem");
            TuSachAdapter adapter = new TuSachAdapter(getActivity().getSupportFragmentManager());
            adapter.setTitle(listTitle);
            viewPager.setAdapter(adapter);
            tabLayout.setupWithViewPager(viewPager);
        }
        return  view;
    }


}
