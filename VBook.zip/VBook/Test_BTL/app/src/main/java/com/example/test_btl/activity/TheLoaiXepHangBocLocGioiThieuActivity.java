package com.example.test_btl.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.test_btl.R;
import com.example.test_btl.fragment.thuvien.FragmentBoloc;
import com.example.test_btl.fragment.thuvien.FragmentGioithieu;
import com.example.test_btl.fragment.thuvien.FragmentTablayoutTheloai;
import com.example.test_btl.fragment.thuvien.FragmentTablayoutXephang;

public class TheLoaiXepHangBocLocGioiThieuActivity extends AppCompatActivity {

    private Fragment selectedFragment = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        Intent intent = getIntent();
        String noidung = intent.getStringExtra("category");
        switch (Integer.parseInt(noidung)){
            case 0:
                selectedFragment = new FragmentTablayoutTheloai();
                break;
            case 1:
                selectedFragment = new FragmentTablayoutXephang();
                break;
            case 2:
                selectedFragment = new FragmentBoloc();
                break;
            default:
                selectedFragment = new FragmentGioithieu();
                break;
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout_category,selectedFragment).commit();
    }
}