package com.example.test_btl.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Chap implements Serializable {
    @SerializedName("Id")
    @Expose
    private String id;
    @SerializedName("Tenchap")
    @Expose
    private String tenchap;
    @SerializedName("Noidung")
    @Expose
    private String noidung;
    @SerializedName("Id_truyen")
    @Expose
    private String idTruyen;

    public Chap(String id,String tenchap, String noidung, String idTruyen) {
        this.id = id;
        this.tenchap = tenchap;
        this.noidung = noidung;
        this.idTruyen = idTruyen;
    }



    public String getTenchap() {
        return tenchap;
    }

    public void setTenchap(String tenchap) {
        this.tenchap = tenchap;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNoidung() {
        return noidung;
    }

    public void setNoidung(String noidung) {
        this.noidung = noidung;
    }

    public String getIdTruyen() {
        return idTruyen;
    }

    public void setIdTruyen(String idTruyen) {
        this.idTruyen = idTruyen;
    }
}
