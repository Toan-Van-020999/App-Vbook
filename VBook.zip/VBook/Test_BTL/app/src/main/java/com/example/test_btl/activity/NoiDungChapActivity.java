package com.example.test_btl.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.test_btl.R;
import com.example.test_btl.adapter.thuvien.NoiDungChapAdapter;
import com.example.test_btl.model.Chap;
import com.example.test_btl.model.Truyen;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NoiDungChapActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private TextView txtcontentChap;
    private Chap chap,chapReceive;
    private Truyen truyen;
    private RecyclerView rcv;
    private ProgressBar progressBar;
    private ArrayList<Chap> dataArraylist = new ArrayList<>();
    private NoiDungChapAdapter adapter;
    private int chapterNumber = 1,totalChap = 1;
    private NestedScrollView nestedScrollView;
    private TextView tenChap;
    private boolean isLoading ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noidung_chap);

        anhXa();
        actionBar();
        if (chapterNumber == 1){
            progressBar.setVisibility(View.GONE);
        }
        chapReceive = (Chap)getIntent().getSerializableExtra("thongtinchap");
        if (chapReceive != null) {
            String nameChapReceive = chapReceive.getTenchap();
            String[] arrayFirstString = nameChapReceive.split(":");
            String[] arraySecondString = arrayFirstString[0].split(" ");
            chapterNumber = Integer.parseInt(arraySecondString[1]);
        }
        truyen = (Truyen) getIntent().getSerializableExtra("tale");
        totalChap = Integer.parseInt(getIntent().getStringExtra("totalChap"));
        getData();
        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if ((scrollY == v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight()) && chapterNumber < totalChap ){
                    if(!isLoading) {
                        loadChap();
                    }
                }
            }
        });
    }

    private void actionBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void anhXa() {
        toolbar = findViewById(R.id.toolbarrrr);
        nestedScrollView = findViewById(R.id.scroll_view);
        rcv = findViewById(R.id.rcv_contentchap);
        progressBar = findViewById(R.id.progeessBar);
        tenChap = findViewById(R.id.txttenchap);
    }

    private void loadChap(){
        isLoading = true;
        progressBar.setVisibility(View.VISIBLE);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    chapterNumber++;
                    getData();
                    nestedScrollView.scrollTo(0, 0);
                    isLoading = false;
                }
            }, 2000);
    }
    private void getData() {
        truyen = (Truyen) getIntent().getSerializableExtra("tale");
        Dataservice dataservice = APIService.getService();
        Call<Chap> callback = dataservice.GetDataChap(truyen.getId(),chapterNumber );
        callback.enqueue(new Callback<Chap>() {
            @Override
            public void onResponse(Call<Chap> call, Response<Chap> response) {
                if (response.body() != null && response.isSuccessful()){
                    progressBar.setVisibility(View.GONE);
                    Chap chap = response.body();
                    tenChap.setText(chap.getTenchap());
                    ArrayList<Chap> list = new ArrayList<>();
                    list.add(chap);
                    NoiDungChapAdapter adapter = new NoiDungChapAdapter(NoiDungChapActivity.this,list);
                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(NoiDungChapActivity.this);
                    linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
                    rcv.setLayoutManager(linearLayoutManager);
                    rcv.setHasFixedSize(true);
                    rcv.setAdapter(adapter);
                }
            }
            @Override
            public void onFailure(Call<Chap> call, Throwable t) {
            }
        });
    }
}