package com.example.test_btl.adapter.thuvien;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.example.test_btl.R;
import com.example.test_btl.model.Chap;

import java.util.ArrayList;

public class DanhSachChapAdapter extends BaseAdapter implements Filterable {

    private int layout;
    private Context context;
    private ArrayList<Chap> list;
    private ArrayList<Chap> listold;

    public DanhSachChapAdapter(int layout, Context context, ArrayList<Chap> list) {
        this.layout = layout;
        this.context = context;
        this.list = list;
        this.listold = list;
    }


    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }



    public class ViewHolder{
        TextView chap;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = new ViewHolder();
        if(convertView == null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(layout,null);
            holder.chap = convertView.findViewById(R.id.chap);
            convertView.setTag(holder);
        }else{
            holder= (ViewHolder) convertView.getTag();
        }
        Chap c = list.get(position);
        holder.chap.setText(c.getTenchap());
        return  convertView;
    }

    public ArrayList<Chap> getList() {
        return list;
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                String strSearch = constraint.toString().toLowerCase().trim();
                if (strSearch.isEmpty()){
                    list = listold;
                }else{
                    ArrayList<Chap> listNew = new ArrayList<>();
                    for (Chap chap:
                            listold) {
                        if(chap.getTenchap().toLowerCase().contains(strSearch)){
                            listNew.add(chap);
                        }
                    }
                    list = listNew;
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = list;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                list = (ArrayList<Chap>) results.values;
                notifyDataSetChanged();
            }
        };
    }

}
