package com.example.test_btl.adapter.thuvien;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.test_btl.R;
import com.example.test_btl.model.Chap;

import java.util.ArrayList;

public class NoiDungChapAdapter extends RecyclerView.Adapter<NoiDungChapAdapter.Viewholder>{

    private Context context;
    private ArrayList<Chap> arrayList ;

    public NoiDungChapAdapter(Context context, ArrayList<Chap> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row,parent,false);
        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, int position) {
        Chap chap = arrayList.get(position);
        holder.noidung.setText(android.text.Html.fromHtml(chap.getNoidung()));
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public  class Viewholder extends RecyclerView.ViewHolder{

        TextView noidung;
        public Viewholder(@NonNull View itemView) {
            super(itemView);
            noidung = itemView.findViewById(R.id.txtcontent);
        }
    }
}
