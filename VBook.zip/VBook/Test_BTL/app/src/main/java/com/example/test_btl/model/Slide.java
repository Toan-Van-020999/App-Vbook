package com.example.test_btl.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Slide {

@SerializedName("Id")
@Expose
private String id;
@SerializedName("Ten")
@Expose
private String ten;
@SerializedName("Anh")
@Expose
private String anh;
@SerializedName("Tacgia")
@Expose
private String tacgia;
@SerializedName("Chuong")
@Expose
private String chuong;


public String getId() {
return id;
}

public void setId(String id) {
this.id = id;
}

public String getTen() {
return ten;
}

public void setTen(String ten) {
this.ten = ten;
}

public String getAnh() {
return anh;
}

public void setAnh(String anh) {
this.anh = anh;
}

public String getTacgia() {
return tacgia;
}

public void setTacgia(String tacgia) {
this.tacgia = tacgia;
}

public String getChuong() {
return chuong;
}

public void setChuong(String chuong) {
this.chuong = chuong;
}


}