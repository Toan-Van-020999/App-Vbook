package com.example.test_btl.service;

import com.example.test_btl.model.Slide;
import com.example.test_btl.model.TheLoai;
import com.example.test_btl.model.Chap;
import com.example.test_btl.model.BinhLuan;
import com.example.test_btl.model.Demluotbinhluan;
import com.example.test_btl.model.Demluotdecu;
import com.example.test_btl.model.Demluottheodoi;
import com.example.test_btl.model.Demluotyeuthich;
import com.example.test_btl.model.Account;
import com.example.test_btl.model.Truyen;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

public interface Dataservice {
    @GET("getdata_banner.php")
    Call< List<Slide> > GetDataBanner();

    @GET("getdata_newcomic_update.php")
    Call<List<Truyen>> GetDataNewTaleUpdate();

    @GET("getdata_newtale.php")
    Call<List<Truyen>> GetDataNewTale();

    @GET("getdata_tale_finish.php")
    Call<List<Truyen>> GetDataTaleFinish();

    @GET("getdata_talemostview.php")
    Call<List<Truyen>> GetDataTaleMostview();

    @GET("getdata_talenomination.php")
    Call<List<Truyen>> GetDataTaleNomination();




    @GET("getdata_xemthem_newtale_update.php")
    Call<List<Truyen>> GetDataXemthemNewtaleUpdate(@Query("offset") int offset);

    @GET("getdata_xemthem_newtale.php")
    Call<List<Truyen>> GetDataXemthemNewtale();

    @GET("getdata_xemthem_mostview.php")
    Call<List<Truyen>> GetDataXemthemMostview(@Query("offset") int offset);

    @GET("getdata_xemthem_tale_finish.php")
    Call<List<Truyen>> GetDataXemthemTalefinish(@Query("offset") int offset);

    @GET("getdata_xemthem_talenomination.php")
    Call<List<Truyen>> GetDataXemthemTalenomination(@Query("offset") int offset);

    @GET("getdata_category.php")
    Call<List<TheLoai>> GetDataCategory();



    @GET("getdata_search_activityMain.php")
    Call< List<Truyen> > GetDataSearchMainActivity(@Query("offset") int offset);



    @GET("getdata_truyencungtacgia.php")
    Call<List<Truyen>> GetDataTruyenCungTacgia(@Query("tacgia") String tacgia,
                                               @Query("id") String id);
    @GET("getdata_listchap.php")
    Call<List<Chap>> GetDataListChap(@Query("id") String id_truyen);

    @GET("getdata_tale_category.php")
    Call<List<Truyen>> GetDataListTaleCategory(@Query("id") String id_theloai);

    @GET("getdata_view.php")
    Call<String> GetDataView(@Query("id") String id_truyen);

    @GET("getdata_topyeuthich.php")
    Call<List<Truyen>> GetDataTopyeuthich();

    @GET("getdata_toptheodoi.php")
    Call<List<Truyen>> GetDataToptheodoi();

    @GET("getdata_topbinhluan.php")
    Call<List<Truyen>> GetDataTopbinhluan();

    @GET("getdata_topxemnhieunhat.php")
    Call<List<Truyen>> GetDataTopxemnhieunhat();

    @GET("getdata_boloc.php")
    Call<List<Truyen>> GetdataBoloc(@QueryMap Map<String,String> options);

    @FormUrlEncoded
    @POST("getdata_login.php")
    Call<Account> GetDataLogin(@Field("username") String username,
                               @Field("password") String password);

    @GET("getdata_countuserlove.php")
    Call<Demluotyeuthich> GetDataCountLove(@Query("id_truyen") String id_truyen);

    @GET("getdata_countusercomment.php")
    Call<Demluotbinhluan> GetDataCountComment(@Query("id_truyen") String id_truyen);

    @GET("getdata_countuserfollow.php")
    Call<Demluottheodoi>  GetDataCountFollow(@Query("id_truyen") String id_truyen);

    @GET("getdata_countusernominations.php")
    Call<Demluotdecu> GetDataCountNominatios(@Query("id_truyen") String id_truyen);

    @FormUrlEncoded
    @POST("update_love.php")
    Call<String> UpdateLove(  @Field("iduser") String iduser,
                            @Field("id_truyen") String id_truyen,
                            @Field("tick") String tick) ;

    @FormUrlEncoded
    @POST("update_follow.php")
    Call<String> UpdateFollow(@Field("iduser") String iduser,
                            @Field("id_truyen") String id_truyen,
                            @Field("tick") String tick) ;

    @FormUrlEncoded
    @POST("update_Nomination.php")
    Call<String> UpdateNomination(@Field("iduser") String iduser,
                                @Field("id_truyen") String id_truyen,
                                @Field("tick") String tick) ;

    @FormUrlEncoded
    @POST("update_view.php")
    Call<String> UpdateView(@Field("id_truyen") String id_truyen,
                            @Field("idUser") String iduser);




    @FormUrlEncoded
    @POST("update_comment.php")
    Call<String> UpdateComment(@Field("iduser") String iduser,
                               @Field("id_truyen") String id_truyen,
                               @Field("noidung") String noidung,
                               @Field("thoigian") String thoigian) ;

    @GET("getdata_comment.php")//k phai
    Call<List<BinhLuan>> GetDataComment(@Query("id_truyen") String id_truyen);

    @GET("getdata_chap.php")
    Call<Chap> GetDataChap(@Query("id_truyen") String id_truyen,
                                 @Query("tick") int tick);

    @GET("getdata_searchview_all.php")
    Call<List<Truyen>> GetDataSearchViewAll();

    @GET("getdata_searchview_newtale.php")
    Call<List<Truyen>> GetDataSearchViewNewTale();

    @GET("getdata_searchview_newtaleupdate.php")
    Call<List<Truyen>> GetDataSearchViewNewTaleUpdate();

    @GET("getdata_searchview_talemostview.php")
    Call<List<Truyen>> GetDataSearchViewTaleMostView();

    @GET("getdata_searchview_talefinish.php")
    Call<List<Truyen>> GetDataSearchViewTaleFinish();

    @GET("getdata_searchview_nominations.php")
    Call<List<Truyen>> GetDataSearchViewNomination();

    @GET("getdata_truyendadang.php")
    Call<List<Truyen>> GetDataTruyenDaDang(@Query("idaccount") String idaccount);

    @GET("getdata_truyenyeuthich.php")
    Call<List<Truyen>> GetDataTruyenYeuThich(@Query("idaccount") String idaccount);

    @GET("getdata_truyenbinhluan.php")
    Call<List<Truyen>> GetDataTruyenBinhLuan(@Query("idaccount") String idaccount);

    @GET("getdata_tale_following.php")
    Call<List<Truyen>> GetDataTruyenDangTheoDoi(@Query("idaccount") String idaccount);

    @GET("getdata_tale_newview.php")
    Call<List<Truyen>> GetDataTruyenVuaXem(@Query("idaccount") String idaccount);

    @FormUrlEncoded
    @POST("uploadhinhanh.php")
    Call<String> uploadImage(
            @Field("EN_IMAGE") String encodedImage,
            @Field("ID_USER") String idUser);
}
