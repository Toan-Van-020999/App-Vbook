package com.example.test_btl.adapter.thuvien;

import android.os.Bundle;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.test_btl.fragment.thuvien.FragmentViewpagerTheloai;
import com.example.test_btl.model.TheLoai;

import java.util.ArrayList;
import java.util.List;

public class TheloaiAdapter extends FragmentPagerAdapter {

    private List<TheLoai> categories = new ArrayList<>();

    public TheloaiAdapter(@NonNull FragmentManager fm) {
         super(fm);
    }
    @NonNull
    @Override
    public Fragment getItem(int position) {;
        Bundle data = new Bundle();
        data.putString("category_id",categories.get(position).getId());
        Fragment fragment = new FragmentViewpagerTheloai();
        fragment.setArguments(data);//set data cho fragments.
        return fragment;
    }

    @Override
    public int getCount() {
        return categories.size();
    }


    public void setCategories(List<TheLoai> categories){
        this.categories = categories;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return categories.get(position).getTen();
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        return;
    }
}
