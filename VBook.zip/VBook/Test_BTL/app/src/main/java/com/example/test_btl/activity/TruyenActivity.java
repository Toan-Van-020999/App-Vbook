    package com.example.test_btl.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.test_btl.R;
import com.example.test_btl.adapter.thuvien.TruyenMoiAdapter;
import com.example.test_btl.model.Demluotbinhluan;
import com.example.test_btl.model.Demluotdecu;
import com.example.test_btl.model.Demluottheodoi;
import com.example.test_btl.model.Demluotyeuthich;
import com.example.test_btl.model.Truyen;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TruyenActivity extends AppCompatActivity implements View.OnClickListener {

    private CollapsingToolbarLayout collapsingToolbarLayout;
    private Toolbar toolbar;
    private RecyclerView rcv;
    private RelativeLayout relativeLayout;
    private BottomNavigationView bottomNavigationView;
    private ImageView img;
    private Truyen truyen;
    private TextView txtgioithieu,txtsochuong,txttacgia,txttrangthai,txtsoluotxem,txtdschuong,numberyeuthich,textyeuthich,numbertheodoi,texttheodoi,numberbinhluan,textbinhluan,numberdecu,textdecu;
    private LinearLayout llyeuthich,llbinhluan,lltheodoi,lldecu;
    private int chuong,tickLove,tickFollow,tickNominations,numberYeuThich,numberBinhLuan,numberTheoDoi,numberDeCu;
    private SharedPreferences sp ;
    private boolean checkLove = true,checkFollow = true,checkNominations = true;
    private Dataservice dataservice = APIService.getService();
    private String view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_truyen);
        sp = getApplicationContext().getSharedPreferences("dataUser", Context.MODE_PRIVATE);

        anhxa();
        actionBar();
        receiveObject();
        onClickItemRead();
        getDataTruyenCungTacGia();
        sendObject();
        countAndSetColorInteract();
        llyeuthich.setOnClickListener(this);
        llbinhluan.setOnClickListener(this);
        lltheodoi.setOnClickListener(this);
        lldecu.setOnClickListener(this);
    }

    private void anhxa(){
        toolbar = findViewById(R.id.toolbartaleactivity);
        rcv = findViewById(R.id.rcvtruyencungtacgia);
        relativeLayout= findViewById(R.id.dsChuong);
        bottomNavigationView = findViewById(R.id.bottom_nav);
        txtgioithieu = findViewById(R.id.txtgioithieu);
        img = findViewById(R.id.imgTale );
        txtsochuong = findViewById(R.id.txtsoluongchuong);
        txttacgia = findViewById(R.id.txttacgia);
        txttrangthai = findViewById(R.id.txttrangthai);
        txtsoluotxem = findViewById(R.id.txtluotxem);
        txtdschuong =findViewById(R.id.txtdschuong);
        collapsingToolbarLayout = findViewById(R.id.collapsingtoolbar);
        llyeuthich = findViewById(R.id.llyeuthich);
        llbinhluan = findViewById(R.id.llbinhluan);
        lltheodoi = findViewById(R.id.lltheodoi);
        lldecu = findViewById(R.id.lldecu);
        numberyeuthich= findViewById(R.id.numberyeuthich);
        textyeuthich = findViewById(R.id.textyeuthich);
        numberbinhluan= findViewById(R.id.numberbinhluan);
        textbinhluan = findViewById(R.id.textbinhluan);
        numbertheodoi= findViewById(R.id.numbertheodoi);
        texttheodoi = findViewById(R.id.texttheodoi);
        numberdecu= findViewById(R.id.numberdecu);
        textdecu = findViewById(R.id.textdecu);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.llyeuthich:
                int color = numberyeuthich.getCurrentTextColor();
                String hexColor = String.format("#%06X", (0xFFFFFF & color));
                if (hexColor.equals("#000000")){
                    tickLove = 1;
                    numberyeuthich.setTextColor(Color.parseColor("#E13F22"));
                    textyeuthich.setTextColor(Color.parseColor("#E13F22"));
                    numberyeuthich.setText((numberYeuThich += 1) + "");
                } else {
                    tickLove = 0;
                    numberyeuthich.setTextColor(Color.parseColor("#000000"));
                    textyeuthich.setTextColor(Color.parseColor("#000000"));
                    numberyeuthich.setText((numberYeuThich -= 1) + "");
                }
                checkLove = !checkLove;
                break;
            case R.id.llbinhluan:
                Intent intent = new Intent(TruyenActivity.this, BinhLuanActivity.class);
                intent.putExtra("idtale",truyen.getId());
                intent.putExtra("iduser",sp.getString("idUser",""));
                startActivity(intent);
                break;
            case R.id.lltheodoi:
                color = numbertheodoi.getCurrentTextColor();
                hexColor = String.format("#%06X", (0xFFFFFF & color));
                if(hexColor.equals("#000000")){
                    FirebaseMessaging.getInstance().subscribeToTopic("abcde");
                    Toast.makeText(TruyenActivity.this,"Bạn sẽ nhận được thông báo khi truyện này có chương mới",Toast.LENGTH_SHORT).show();
                    tickFollow = 1;
                    numbertheodoi.setTextColor(Color.parseColor("#E13F22"));
                    texttheodoi.setTextColor(Color.parseColor("#E13F22"));
                    numbertheodoi.setText((numberTheoDoi += 1) + "");
                }else{
                    FirebaseMessaging.getInstance().unsubscribeFromTopic("abcde");
                    Toast.makeText(TruyenActivity.this,"Đã tắt nhận thông báo nhận chương mới",Toast.LENGTH_SHORT).show();
                    tickFollow = 0;
                    numbertheodoi.setTextColor(Color.parseColor("#000000"));
                    texttheodoi.setTextColor(Color.parseColor("#000000"));
                    numbertheodoi.setText((numberTheoDoi -= 1) + "");
                }
                checkFollow = !checkFollow;
                break;
            case R.id.lldecu:
                color = numberdecu.getCurrentTextColor();
                hexColor = String.format("#%06X", (0xFFFFFF & color));
                if(hexColor.equals("#000000")){
                    tickNominations = 1;
                    numberdecu.setTextColor(Color.parseColor("#E13F22"));
                    textdecu.setTextColor(Color.parseColor("#E13F22"));
                    numberdecu.setText((numberDeCu += 1) + "");
                }else{
                    tickNominations = 0;
                    numberdecu.setTextColor(Color.parseColor("#000000"));
                    textdecu.setTextColor(Color.parseColor("#000000"));
                    numberdecu.setText((numberDeCu -= 1) + "");
                }
                checkNominations = !checkNominations;
                break;
        }
    }

    private void updateLove(){
        Call<String> callLove = dataservice.UpdateLove(sp.getString("idUser",""),truyen.getId(),tickLove + "");
        callLove.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
            }
            @Override
            public void onFailure(Call<String> call, Throwable t) {
            }
        });
    }
    private void updateFollow(){
        Call<String> callFollow =dataservice.UpdateFollow(sp.getString("idUser",""),truyen.getId(),tickFollow + "");
        callFollow.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
            }
            @Override
            public void onFailure(Call<String> call, Throwable t) {
            }
        });
    }
    private void updateNominations(){
        Call<String> callNomination = dataservice.UpdateNomination(sp.getString("idUser",""),truyen.getId(),tickNominations + "");
        callNomination.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
            }
            @Override
            public void onFailure(Call<String> call, Throwable t) {
            }
        });
    }


    @Override
    protected void onStop() {
        super.onStop();
        if(!checkLove){
            updateLove();
        }
        if(!checkFollow){
            updateFollow();
        }
        if(!checkNominations){
            updateNominations();
        }

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Call<Demluotbinhluan> callComment = dataservice.GetDataCountComment(truyen.getId());
        callComment.enqueue(new Callback<Demluotbinhluan>() {
            @Override
            public void onResponse(Call<Demluotbinhluan> call, Response<Demluotbinhluan> response) {
                Demluotbinhluan demluotbinhluan = response.body();
                numberbinhluan.setText(demluotbinhluan.getCount());

            }

            @Override
            public void onFailure(Call<Demluotbinhluan> call, Throwable t) {

            }
        });
    }

    private void actionBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void countAndSetColorInteract(){
        Call<Demluotyeuthich> callLove = dataservice.GetDataCountLove(truyen.getId());
        callLove.enqueue(new Callback<Demluotyeuthich>() {
            @Override
            public void onResponse(Call<Demluotyeuthich> call, Response<Demluotyeuthich> response) {
                Demluotyeuthich demluotyeuthich = response.body();
                if(demluotyeuthich.getIduser()!= null && demluotyeuthich.getIduser().equals(sp.getString("idUser",""))){
                    numberyeuthich.setTextColor(Color.parseColor("#E13F22"));
                    textyeuthich.setTextColor(Color.parseColor("#E13F22"));
                }else {
                    numberyeuthich.setTextColor(Color.parseColor("#000000"));
                    textyeuthich.setTextColor(Color.parseColor("#000000"));
                }
                    numberyeuthich.setText(demluotyeuthich.getCount());
                    numberYeuThich = Integer.parseInt(demluotyeuthich.getCount());
            }


            @Override
            public void onFailure(Call<Demluotyeuthich> call, Throwable t) {//
            }
        });

        Call<Demluotbinhluan> callComment = dataservice.GetDataCountComment(truyen.getId());
        callComment.enqueue(new Callback<Demluotbinhluan>() {
            @Override
            public void onResponse(Call<Demluotbinhluan> call, Response<Demluotbinhluan> response) {
                Demluotbinhluan demluotbinhluan = response.body();
                numberbinhluan.setText(demluotbinhluan.getCount());

            }

            @Override
            public void onFailure(Call<Demluotbinhluan> call, Throwable t) {

            }
        });
        Call<Demluottheodoi> callFollow = dataservice.GetDataCountFollow(truyen.getId());
        callFollow.enqueue(new Callback<Demluottheodoi>() {
            @Override
            public void onResponse(Call<Demluottheodoi> call, Response<Demluottheodoi> response) {
                Demluottheodoi demluottheodoi = response.body();
                if(demluottheodoi.getIduser()!= null && demluottheodoi.getIduser().equals(sp.getString("idUser",""))){
                    numbertheodoi.setTextColor(Color.parseColor("#E13F22"));
                    texttheodoi.setTextColor(Color.parseColor("#E13F22"));
                }else {
                    numbertheodoi.setTextColor(Color.parseColor("#000000"));
                    texttheodoi.setTextColor(Color.parseColor("#000000"));
                }
                numbertheodoi.setText(demluottheodoi.getCount());
                numberTheoDoi = Integer.parseInt(demluottheodoi.getCount());

            }

            @Override
            public void onFailure(Call<Demluottheodoi> call, Throwable t) {

            }
        });
        Call<Demluotdecu> callNominations = dataservice.GetDataCountNominatios(truyen.getId());
        callNominations.enqueue(new Callback<Demluotdecu>() {
            @Override
            public void onResponse(Call<Demluotdecu> call, Response<Demluotdecu> response) {
                Demluotdecu demluotdecu = response.body();
                if(demluotdecu.getIduser()!= null && demluotdecu.getIduser().equals(sp.getString("idUser",""))){
                    numberdecu.setTextColor(Color.parseColor("#E13F22"));
                    textdecu.setTextColor(Color.parseColor("#E13F22"));
                }else {
                    numberdecu.setTextColor(Color.parseColor("#000000"));
                    textdecu.setTextColor(Color.parseColor("#000000"));
                }
                numberdecu.setText(demluotdecu.getCount());
                numberDeCu = Integer.parseInt(demluotdecu.getCount());
            }

            @Override
            public void onFailure(Call<Demluotdecu> call, Throwable t) {
            }
        });

        Call<String> callCountView = dataservice.GetDataView(truyen.getId());
        callCountView.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                view = response.body();
                if (view.equals("<br")){
                    view = "0";
                }
                txtsoluotxem.setText("Số lượt xem: " + view);

            }
            @Override
            public void onFailure(Call<String> call, Throwable t) {

            }
        });

    }

    private void receiveObject(){
        truyen = (Truyen) getIntent().getSerializableExtra("thongtintruyen");
        txtgioithieu.setText(android.text.Html.fromHtml(truyen.getGioithieu()));
        Glide.with(TruyenActivity.this).load(truyen.getAnh()).into(img);
        txtsochuong.setText("Số Chap: " + (chuong =  Integer.parseInt(truyen.getChuong()) < 50 ? Integer.parseInt(truyen.getChuong()) : 50));
        txttacgia.setText("Tác Giả: " + truyen.getTacgia());
        txttrangthai.setText("Trạng Thái: " + truyen.getTrangthai());
        chuong =  Integer.parseInt(truyen.getChuong()) < 50 ? Integer.parseInt(truyen.getChuong()) : 50;
        txtdschuong.setText(chuong  + " CHƯƠNG" );
        collapsingToolbarLayout.setTitle(truyen.getTen());
    }


    private void getDataTruyenCungTacGia() {
        Dataservice dataservice = APIService.getService();
        Call<List<Truyen>> callback = dataservice.GetDataTruyenCungTacgia(truyen.getTacgia(),truyen.getId());
        callback.enqueue(new Callback<List<Truyen>>() {
            @Override
            public void onResponse(Call<List<Truyen>> call, Response<List<Truyen>> response) {
                ArrayList<Truyen> list = (ArrayList<Truyen>) response.body();
                TruyenMoiAdapter adapter = new TruyenMoiAdapter(TruyenActivity.this,list);
                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(TruyenActivity.this);
                linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
                rcv.setLayoutManager(linearLayoutManager);
                rcv.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<Truyen>> call, Throwable t) {
                Toast.makeText(TruyenActivity.this,"CALL DATA FAILD",Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void onClickItemRead(){
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.read:
                        Call<String> str = dataservice.UpdateView(truyen.getId(),sp.getString("idUser",""));
                        str.enqueue(new Callback<String>() {
                            @Override
                            public void onResponse(Call<String> call, Response<String> response) {
                            }

                            @Override
                            public void onFailure(Call<String> call, Throwable t) {
                            }
                        });
                        Intent intent = new Intent(TruyenActivity.this, NoiDungChapActivity.class);
                        intent.putExtra("tale",truyen);
                        intent.putExtra("totalChap",chuong + "");
                        startActivity(intent);
                        break;

                }
                return false;
            }
        });
    }
    private void sendObject(){
        relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TruyenActivity.this, DanhSachChapActivity.class);
                intent.putExtra("truyen",truyen);
                startActivity(intent);
            }
        });
    }



}