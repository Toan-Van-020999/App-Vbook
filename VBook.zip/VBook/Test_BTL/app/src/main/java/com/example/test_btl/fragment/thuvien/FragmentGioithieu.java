package com.example.test_btl.fragment.thuvien;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.example.test_btl.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class FragmentGioithieu extends Fragment {
    private ViewFlipper viewFlipper;
    private FloatingActionButton buttonCall;
    private String phone  = "0328800262";
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_gioithieu,container,false);
        viewFlipper = view.findViewById(R.id.viewflipper);
        buttonCall = view.findViewById(R.id.buttonCall);

        buttonCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("tel://" + phone)));
            }
        });
        actionViewFlipper();
        return view;
    }

    private void actionViewFlipper() {
        ArrayList<String> mangQuangCao = new ArrayList<>();
        mangQuangCao.add("https://cdn.tgdd.vn/Files/2016/05/12/827516/banner-thegioididong-so1online.jpg");
        mangQuangCao.add("https://i.pinimg.com/736x/52/60/0b/52600b66c2fe8ee1ec765f6c68134fb8.jpg");
        mangQuangCao.add("https://cdn.tgdd.vn/Files/2015/04/25/635920/banner-home.jpg");
        mangQuangCao.add("https://www.thegioididong.com/xa-hang-ton/content/desktop/images/fb-share.png");
        for (int i = 0; i < mangQuangCao.size(); i++) {
            ImageView imageView = new ImageView(getActivity());
            Glide.with(getActivity()).load(mangQuangCao.get(i)).into(imageView);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            viewFlipper.addView(imageView);

        }
        viewFlipper.setFlipInterval(5000);
        viewFlipper.setAutoStart(true);

        Animation animation_in = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_in_right);
        Animation animation_out = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_out_right);

        viewFlipper.setInAnimation(animation_in);
        viewFlipper.setOutAnimation(animation_out);
    }
}
