package com.example.test_btl.fragment.thuvien;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.example.test_btl.R;
import com.example.test_btl.activity.TheLoaiXepHangBocLocGioiThieuActivity;
import com.example.test_btl.activity.NoiDungBolocActivity;
import com.example.test_btl.model.Truyen;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentBoloc extends Fragment {

    private RadioGroup rgTinhtrang,rgSochuong;
    private RadioButton rbSelectedTinhtrang,rbSelectedChuong;
    private CheckBox cbTienhiep,cbKiemhiep,cbNgontinh,cbDothi,cbQuantruong,cbVongdu;
    private Toolbar toolbar;
    private View view;
    private String str = "";
    private Map<String,String> map = new HashMap<>();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
         view = inflater.inflate(R.layout.fragment_boloc_category,container,false);
        anhxa();
        actionBar();
        return view;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.item_toolbar_boloc:
                putMap();
                getData();
        }
        return true;
    }

    private void putMap(){
        List<CheckBox> items = new ArrayList<CheckBox>();
        items.add(cbTienhiep);
        items.add(cbKiemhiep);
        items.add(cbNgontinh);
        items.add(cbDothi);
        items.add(cbQuantruong);
        items.add(cbVongdu);
        int rbSelectedTinhtrangId = rgTinhtrang.getCheckedRadioButtonId();
        rbSelectedTinhtrang = view.findViewById(rbSelectedTinhtrangId);
        if (rbSelectedTinhtrang != null && rbSelectedTinhtrang != view.findViewById(R.id.radiobuttonTinhtrangToanbo)){
            map.put("trangthai",rbSelectedTinhtrang.getText().toString().trim());
        }else {
            map.remove("trangthai");
        }

        int rbSelectedChuongId = rgSochuong.getCheckedRadioButtonId();
        rbSelectedChuong = view.findViewById(rbSelectedChuongId);
        if(rbSelectedChuong != null && rbSelectedChuong != view.findViewById(R.id.radiobuttonToanbochuong)){
            map.put("chuong",rbSelectedChuong.getText().toString().trim());
        }else {
            map.remove("chuong");
        }


        int count = 0,idtheloai = 0;
        for (CheckBox itemm : items){
            idtheloai ++;
            if(itemm.isChecked()){
                count++;
                str += "'" + idtheloai + "'";

                str += ",";

            }
        }

        if(!str.equals("")) {
            str = str.substring(0, str.length() - 1);
            map.put("idtheloai", str);
        }
        else
            map.remove("idtheloai");
    }


    private void anhxa(){
        rgTinhtrang = view.findViewById(R.id.radioGroupTinhtrang);
        rgSochuong = view.findViewById(R.id.radioGroupSochuong);
        cbTienhiep = view.findViewById(R.id.checkboxTienhiep);
        cbKiemhiep = view.findViewById(R.id.checkboxKiemhiep);
        cbNgontinh = view.findViewById(R.id.checkboxNgontinh);
        cbDothi = view.findViewById(R.id.checkboxDothi);
        cbQuantruong = view.findViewById(R.id.checkboxQuantruong);
        cbVongdu = view.findViewById(R.id.checkboxVongdu);
        toolbar = view.findViewById(R.id.toolbarBoloc);
    }

    private void actionBar(){
        ((TheLoaiXepHangBocLocGioiThieuActivity)getContext()).setSupportActionBar(toolbar);
        ((TheLoaiXepHangBocLocGioiThieuActivity)getContext()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        });
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.item_toolbar_boloc,menu);
    }

    @Override
    public void onStop() {
        super.onStop();
        for (int i = 0; i < map.size(); i++) {
            map.remove(i);
        }
    }

    private void getData() {
        Dataservice dataservice = APIService.getService();
        Call<List<Truyen>> callback = dataservice.GetdataBoloc(map);

        callback.enqueue(new Callback<List<Truyen>>() {
            @Override
            public void onResponse(Call<List<Truyen>> call, Response<List<Truyen>> response) {
                ArrayList<Truyen> listTale = (ArrayList<Truyen>) response.body();
                Intent intent = new Intent(getActivity(), NoiDungBolocActivity.class);
                intent.putExtra("listtale",listTale);
                startActivity(intent);
            }
            @Override
            public void onFailure(Call<List<Truyen>> call, Throwable t) {
            }
        });
    }


}
