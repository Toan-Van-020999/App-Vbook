package com.example.test_btl.adapter.tusach;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.test_btl.fragment.tusach.FragmentViewpagerTuSach;

import java.util.ArrayList;

public class TuSachAdapter extends FragmentPagerAdapter {
    private ArrayList<String> listTitle = new ArrayList<>();

    Context c;
    public TuSachAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        Bundle data = new Bundle();
        data.putString("titlebookcase",listTitle.get(position));
        Fragment fragment = new FragmentViewpagerTuSach();
        fragment.setArguments(data);//set data cho fragments.
        return fragment;
    }

    @Override
    public int getCount() {
        return listTitle.size();
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return listTitle.get(position);
    }
    public void setTitle(ArrayList<String> listTitle){
        this.listTitle = listTitle;

    }

}
