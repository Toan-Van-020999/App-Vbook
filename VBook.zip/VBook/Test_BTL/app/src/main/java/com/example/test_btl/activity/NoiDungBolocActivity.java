package com.example.test_btl.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;

import com.example.test_btl.R;
import com.example.test_btl.adapter.thuvien.TaleCategoryAdapter;
import com.example.test_btl.model.Truyen;

import java.util.ArrayList;

public class NoiDungBolocActivity extends AppCompatActivity {

    RecyclerView rcvBoloc;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noidung_boloc);
        rcvBoloc = findViewById(R.id.rvc);
        toolbar = findViewById(R.id.toolbarbolocc);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        ArrayList<Truyen> list = (ArrayList<Truyen>) getIntent().getSerializableExtra("listtale");
        TaleCategoryAdapter adapter = new TaleCategoryAdapter(NoiDungBolocActivity.this,list);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(),3,RecyclerView.VERTICAL,false);
        rcvBoloc.setHasFixedSize(true);
        rcvBoloc.setLayoutManager(gridLayoutManager);
        rcvBoloc.setAdapter(adapter);
    }
}