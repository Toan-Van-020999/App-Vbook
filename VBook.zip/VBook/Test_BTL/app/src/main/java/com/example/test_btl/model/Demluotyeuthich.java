package com.example.test_btl.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Demluotyeuthich {

    @SerializedName("Count")
    @Expose
    private String count;

    @SerializedName("Iduser")
    @Expose
    private String iduser;

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getIduser() {
        return iduser;
    }

    public void setIduser(String iduser) {
        this.iduser = iduser;
    }
}
