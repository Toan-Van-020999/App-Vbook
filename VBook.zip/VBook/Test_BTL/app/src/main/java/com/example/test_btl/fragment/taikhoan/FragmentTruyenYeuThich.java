package com.example.test_btl.fragment.taikhoan;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.test_btl.R;
import com.example.test_btl.adapter.thuvien.TaleCategoryAdapter;
import com.example.test_btl.model.Truyen;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentTruyenYeuThich extends Fragment {
    private RecyclerView rcvTruyenYeuThich = null;
    private SharedPreferences sp;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_noidung_boloc,container,false);
        sp = getActivity().getSharedPreferences("dataUser", Context.MODE_PRIVATE);
        rcvTruyenYeuThich = view.findViewById(R.id.rvc);
        getDataTruyenYeuThich();
        return view;
    }

    private void getDataTruyenYeuThich() {
        Dataservice dataservice = APIService.getService();
        dataservice = APIService.getService();
        Call<List<Truyen>> callback = dataservice.GetDataTruyenYeuThich(sp.getString("idUser",""));
        callback.enqueue(new Callback<List<Truyen>>() {
            @Override
            public void onResponse(Call<List<Truyen>> call, Response<List<Truyen>> response) {
                ArrayList<Truyen> list = (ArrayList<Truyen>) response.body();
                TaleCategoryAdapter adapter = new TaleCategoryAdapter(getActivity(),list);
                GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity().getApplicationContext(),3, RecyclerView.VERTICAL,false);
                rcvTruyenYeuThich.setHasFixedSize(true);
                rcvTruyenYeuThich.setLayoutManager(gridLayoutManager);
                rcvTruyenYeuThich.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<Truyen>> call, Throwable t) {
            }
        });
    }
}
