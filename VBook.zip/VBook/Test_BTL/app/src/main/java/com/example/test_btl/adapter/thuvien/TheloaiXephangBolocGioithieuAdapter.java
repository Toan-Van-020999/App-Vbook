package com.example.test_btl.adapter.thuvien;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.test_btl.R;
import com.example.test_btl.model.TheLoai;

import java.util.List;

public class TheloaiXephangBolocGioithieuAdapter extends BaseAdapter {
    private Context context;
    private int idlayout;
    private List<TheLoai> list;

    public TheloaiXephangBolocGioithieuAdapter(Context context, int idlayout, List<TheLoai> list) {
        this.context = context;
        this.idlayout = idlayout;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private static class ViewHolder{
        ImageView imageView;
        TextView txtname;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        ViewHolder holder = new ViewHolder();

        if(row == null) {
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row =layoutInflater.inflate(idlayout,null);

            holder.txtname = row.findViewById(R.id.textView);
            holder.imageView = row.findViewById(R.id.imageView);
            row.setTag(holder);
        }else{
            holder = (ViewHolder) row.getTag();
        }

        TheLoai category = list.get(position);
        holder.txtname .setText(category.getTen());
        holder.imageView.setImageResource(category.getImg());

        return  row;
    }

}
