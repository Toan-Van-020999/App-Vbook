package com.example.test_btl.fragment.thuvien;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.test_btl.R;
import com.example.test_btl.activity.TheLoaiXepHangBocLocGioiThieuActivity;
import com.example.test_btl.adapter.thuvien.TheloaiXephangBolocGioithieuAdapter;
import com.example.test_btl.model.TheLoai;

import java.util.ArrayList;

public class FragmentTheLoaiXephangBolocGioithieu extends Fragment {

    private GridView gridView;
    private View view;
    private ArrayList<TheLoai> arrayList = new ArrayList<>();
    private TheloaiXephangBolocGioithieuAdapter adapter;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_category,container,false);
        gridView = view.findViewById(R.id.gridview);
        adapter = new TheloaiXephangBolocGioithieuAdapter(getActivity(),R.layout.dong_category,arrayList);

        arrayList.add(new TheLoai(R.drawable.list,"Thể loại"));
        arrayList.add(new TheLoai(R.drawable.star,"Xếp hạng"));
        arrayList.add(new TheLoai(R.drawable.loc,"Bộ lọc"));
        arrayList.add(new TheLoai(R.drawable.intro,"Giới thiệu"));

        gridView.setAdapter(adapter);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getActivity(), TheLoaiXepHangBocLocGioiThieuActivity.class);
                intent.putExtra("category",position + "");
                startActivity(intent);
            }
        });
        return  view;
    }


}
