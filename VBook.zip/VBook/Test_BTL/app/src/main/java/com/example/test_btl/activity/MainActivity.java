package com.example.test_btl.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.test_btl.ListenEventNetwork;
import com.example.test_btl.R;
import com.example.test_btl.fragment.tusach.FragmentTablayoutTuSach;
import com.example.test_btl.fragment.thuvien.FragmentThuVien;
import com.example.test_btl.fragment.taikhoan.FragmentTaiKhoan;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private long backPressedTime;
    private BottomNavigationView bottomNavigationView;
    private Fragment selectedFragment = null ;
    private SharedPreferences sp;
    private Fragment fragmentTablayoutTusach;
    private Fragment fragmentThuVien;
    private Fragment fragmentTaikhoan;
    private int currentSelectedItemId = R.id.action_thuvien;
    private ListenEventNetwork listenEventNetwork;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bottomNavigationView = findViewById(R.id.bottom_nav);
        sp = getApplicationContext().getSharedPreferences("dataUser", MODE_PRIVATE);


        createObject();
        receiver();
        FragmentDefault();
        FragmentSelector();
        createNotificationChannel();
        registerBroadcastReceiver();
    }

    private void createObject() {
        listenEventNetwork = new ListenEventNetwork();
        fragmentTablayoutTusach = new FragmentTablayoutTuSach();
        fragmentThuVien = new FragmentThuVien();
        fragmentTaikhoan = new FragmentTaiKhoan();
    }

    private void registerBroadcastReceiver(){
        IntentFilter intentFilter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(listenEventNetwork,intentFilter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(listenEventNetwork);

    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("1111", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void FragmentSelector() {
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.action_tusach:
                        selectedFragment = fragmentTablayoutTusach;
                        break;
                    case R.id.action_thuvien:
                        selectedFragment = fragmentThuVien;
                        break;
                    case R.id.action_taikhoan:
                        selectedFragment = fragmentTaikhoan;
                        break;
                }
                if(currentSelectedItemId != item.getItemId()) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout,selectedFragment).commit();
                }
                currentSelectedItemId = item.getItemId();
                return true;
            }
        });
    }

    private void FragmentDefault() {
        getSupportFragmentManager().beginTransaction().add(R.id.fragment_layout,fragmentThuVien).commit();
        bottomNavigationView.setSelectedItemId(R.id.action_thuvien);

    }

    private void receiver() {
        if (sp.getString("idUser","").equals("") ){
            Intent intent = new Intent(MainActivity.this, DangNhapActivity.class);
            startActivity(intent);
        }
    }

    @Override
    public void onBackPressed() {
        if(backPressedTime + 2000 > System.currentTimeMillis()) {
            super.onBackPressed();
            moveTaskToBack(true);
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);
        }else{
            Toast.makeText(MainActivity.this,"Chạm lần nữa để thoát",Toast.LENGTH_SHORT).show();
        }
        backPressedTime = System.currentTimeMillis();
    }
}