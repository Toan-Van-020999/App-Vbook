package com.example.test_btl.fragment.thuvien;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;


import com.example.test_btl.activity.MainActivity;
import com.example.test_btl.R;
import com.example.test_btl.activity.ListTaleActivity;

public class FragmentThuVien extends Fragment {
    private Toolbar toolbar;
    private ScrollView scrollView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private TextView txtThuVien;
    private View view;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            view = inflater.inflate(R.layout.fragment_thuvien, container, false);
            toolbar = view.findViewById(R.id.toolbarthuvien);
            ((MainActivity) getContext()).setSupportActionBar(toolbar);

            txtThuVien = view.findViewById(R.id.txtthuvien);
            swipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout);
            swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getActivity(), "refresh data", Toast.LENGTH_SHORT).show();
                        }
                    }, 2000);
                    swipeRefreshLayout.setRefreshing(false);
                }
            });
        return  view;
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu,inflater);
        inflater.inflate(R.menu.item_toolbar_home,menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if( id == R.id.action_search_toolbar){
            SharedPreferences sharedPreferences = getActivity().getSharedPreferences("xemthem", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("search","all");
            editor.apply();
            Intent intent = new Intent(getActivity(), ListTaleActivity.class);
            intent.putExtra("more","all");
            startActivity(intent);
        }
        return false;
    }
}
