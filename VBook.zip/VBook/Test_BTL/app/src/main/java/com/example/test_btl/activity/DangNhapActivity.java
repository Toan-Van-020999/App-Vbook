package com.example.test_btl.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.test_btl.R;
import com.example.test_btl.model.Account;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DangNhapActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText username,password;
    private Button btnLogin;
    private SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        anhxa();
        btnLogin.setOnClickListener(this);
    }

    private void anhxa() {
        username = findViewById(R.id.tendangnhap);
        password = findViewById(R.id.matkhaudangnhap);
        btnLogin = findViewById(R.id.btndangnhap);
    }

    public void login(){
        Dataservice dataservice = APIService.getService();
        Call<Account> callback = dataservice.GetDataLogin(username.getText().toString().trim(),password.getText().toString().trim());
        callback.enqueue(new Callback<Account>() {
            @Override
            public void onResponse(Call<Account> call, Response<Account> response) {
                    Account account = response.body();
                    if (account != null){
                        sp = getSharedPreferences("dataUser",MODE_PRIVATE);
                        SharedPreferences.Editor editor = sp.edit();
                        editor.putString("idUser", account.getId());
                        editor.putString("taikhoan", account.getUsername());
                        editor.putString("image", account.getImage());
                        editor.commit();

                        Intent intent = new Intent(DangNhapActivity.this,MainActivity.class);
                        startActivity(intent);
                    }
            }

            @Override
            public void onFailure(Call<Account> call, Throwable t) {
                Toast.makeText(DangNhapActivity.this,"Tài khoản hoặc mật khẩu không chính xác",Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btndangnhap:
                if(TextUtils.isEmpty(username.getText().toString()) || TextUtils.isEmpty(username.getText().toString())){
                    Toast.makeText(DangNhapActivity.this,"Vui lòng nhâp đề đủ thông tin",Toast.LENGTH_SHORT).show();
                }else {
                    login();
                }
                break;
        }
    }
}