package com.example.test_btl.adapter.thuvien;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.test_btl.R;
import com.example.test_btl.activity.TruyenActivity;
import com.example.test_btl.model.Truyen;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TaleCategoryAdapter extends RecyclerView.Adapter<TaleCategoryAdapter.ViewHolder> implements Filterable {

    private Context context;
    private ArrayList<Truyen> arrayList;
    private ArrayList<Truyen> arrayListOld;
    private SharedPreferences sp;
    private String key = "";
    public TaleCategoryAdapter(Context context, ArrayList<Truyen> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
        this.arrayListOld = arrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater =LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.dong_tale_category,parent,false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Truyen taleCategory = arrayList.get(position);
        holder.tentruyen.setText(taleCategory.getTen());
        Glide.with(context).load(taleCategory.getAnh()).placeholder(R.drawable.book).error(R.drawable.error).into(holder.img);
    }

    @Override
    public int getItemCount() {
        if (arrayList != null   ){
            return arrayList.size();
        }
        return  0;
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                sp = context.getSharedPreferences("xemthem", Context.MODE_PRIVATE);
                key = sp.getString("search","");
                Dataservice dataservice = APIService.getService();
                String strSearch = constraint.toString().toLowerCase().trim();
                if(strSearch.isEmpty()){
                    arrayList = arrayListOld;
                }else{
                    Call<List<Truyen>> callback = null;
                    switch (key){
                        case "all":
                            callback = dataservice.GetDataSearchViewAll();
                            break;
                        case "newtale":
                            callback = dataservice.GetDataSearchViewNewTale();
                            break;
                        case "newtaleupdate":
                            callback = dataservice.GetDataSearchViewNewTaleUpdate();
                            break;
                        case "talefinish":
                            callback = dataservice.GetDataSearchViewTaleFinish();
                            break;
                        case "talemostview":
                            callback = dataservice.GetDataSearchViewTaleMostView();
                            break;
                        case "talenomination":
                            callback = dataservice.GetDataSearchViewNomination();
                            break;
                    }
                    callback.enqueue(new Callback<List<Truyen>>() {
                        @Override
                        public void onResponse(Call<List<Truyen>> call, Response<List<Truyen>> response) {
                            ArrayList<Truyen>  arrayListOld = (ArrayList<Truyen>) response.body();
                            List<Truyen> listVisible = new ArrayList<>();
                            for (Truyen tale:
                                 arrayListOld) {
                               if (tale.getTen().toLowerCase().trim().contains(strSearch)){
                                   listVisible.add(tale);
                               }
                            }
                            arrayList = (ArrayList<Truyen>) listVisible;
                        }
                        @Override
                        public void onFailure(Call<List<Truyen>> call, Throwable t) {
                        }
                    });
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = arrayList;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                arrayList = (ArrayList<Truyen>) results.values;
                notifyDataSetChanged();
            }
        };
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView img;
        TextView tentruyen;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.imgtalecategory);
            tentruyen = itemView.findViewById(R.id.txttentruyen);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, TruyenActivity.class);
                    intent.putExtra("thongtintruyen",arrayList.get(getPosition()));
                    context.startActivity(intent);
                }
            });
        }
    }
}
