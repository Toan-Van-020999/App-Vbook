package com.example.test_btl.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;

import com.example.test_btl.R;
import com.example.test_btl.adapter.thuvien.DanhSachChapAdapter;
import com.example.test_btl.model.Chap;
import com.example.test_btl.model.Truyen;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DanhSachChapActivity extends AppCompatActivity {

    ListView listView;
    SearchView searchView;
    Truyen truyen;
    DanhSachChapAdapter adapter;
    Toolbar toolbar;
    ArrayList<Chap> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_chapter);

        anhxa();
        truyen = (Truyen) getIntent().getSerializableExtra("truyen");
        getData();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent2 = new Intent(DanhSachChapActivity.this, NoiDungChapActivity.class);
                intent2.putExtra("thongtinchap",adapter.getList().get(position));
                intent2.putExtra("totalChap",list.size() + "");
                intent2.putExtra("tale",truyen);
                startActivity(intent2);
            }
        });
    }

    private void anhxa() {
        searchView = findViewById(R.id.timkiemchapter);
        listView = findViewById(R.id.listviewchapter);
        toolbar = findViewById(R.id.toolbarlistchapter);
    }

    private void getData() {
        Dataservice dataservice = APIService.getService();
        Call<List<Chap>> callback = dataservice.GetDataListChap(truyen.getId());
        callback.enqueue(new Callback<List<Chap>>() {
            @Override
            public void onResponse(Call<List<Chap>> call, Response<List<Chap>> response) {
                list = (ArrayList<Chap>) response.body();
                 adapter = new DanhSachChapAdapter(R.layout.dong_chap, DanhSachChapActivity.this,list);
                listView.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<Chap>> call, Throwable t) {
            }
        });
    }


}