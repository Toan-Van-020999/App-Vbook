package com.example.test_btl.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;

import com.example.test_btl.R;
import com.example.test_btl.adapter.thuvien.TaleCategoryAdapter;
import com.example.test_btl.model.Truyen;
import com.example.test_btl.service.APIService;
import com.example.test_btl.service.Dataservice;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListTaleActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private RecyclerView recyclerView;
    private Context context;
    private String noidung;
    private SearchView searchView;
    private NestedScrollView nestedScrollView;
    private TaleCategoryAdapter adapter;
    private ProgressBar progressBar;
    private TextView txttieude;
    private boolean isLoading,checkMaxList = true;
    private ArrayList<Truyen> arrayList1 = new ArrayList<>();
    private int offset = 0;
    private boolean checkSearchView = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danhsachtruyen);

        anhXa();
        actionBar();
        reciverData();
        getDataXemthem();
        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if ((scrollY == v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight()) && checkMaxList && !noidung.equals("3")){
                    if (!isLoading && checkSearchView) {
                            offset += 21;
                            loadTale();
                    }
                }
            }
        });
        searchView();
    }

    private void loadTale() {
        isLoading = true;
        getDataXemthem();
        isLoading = false;
    }

    private void searchView(){
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter.getFilter().filter(query);
                if (query == null || query.equals("")){
                    checkSearchView = true;
                }else {
                    checkSearchView = false;
                }
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                if (newText == null || newText.equals("")){
                    checkSearchView = true;
                }else {
                    checkSearchView = false;
                }
                return false;
            }
        });
            if (!checkSearchView) {
                progressBar.setVisibility(View.GONE);
            }
    }
    private void reciverData() {
        Intent intent = getIntent();
        noidung = intent.getStringExtra("more");
    }
    private void actionBar(){
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void anhXa(){
        toolbar = findViewById(R.id.toolbar);
        nestedScrollView = findViewById(R.id.sv_listTale);
        recyclerView = findViewById(R.id.rcv_listTale);
        txttieude = findViewById(R.id.txttieude);
        progressBar = findViewById(R.id.pgb_listTale);
        searchView =findViewById(R.id.searchView);
        searchView.setMaxWidth(Integer.MAX_VALUE);
    }

    private void getDataXemthem() {
        Dataservice dataservice = APIService.getService();
        Call<List<Truyen>> callback ;
        if(noidung.equals("newtaleupdate")){
            callback = dataservice.GetDataXemthemNewtaleUpdate(offset);
            txttieude.setText("TRUYỆN MỚI CẬP NHẬT");
        }else if(noidung.equals("talenomination")){
            callback = dataservice.GetDataXemthemTalenomination(offset);
            txttieude.setText("TRUYỆN ĐỀ CỬ");
        }
        else if(noidung.equals("newtale")) {
            callback = dataservice.GetDataXemthemNewtale();
            txttieude.setText("TRUYỆN MỚI");
        }
        else if(noidung.equals("talefinish")) {
            callback = dataservice.GetDataXemthemTalefinish(offset);
            txttieude.setText("TRUYỆN HOÀN THÀNH");
        }
        else if(noidung.equals("talemostview")){
            callback = dataservice.GetDataXemthemMostview(offset);
            txttieude.setText("TRUYỆN ĐỌC NHIỀU NHẤT");
        }
        else {
            callback = dataservice.GetDataSearchMainActivity(offset);
            txttieude.setText("DANH SÁCH CÁC TRUYỆN");
        }
        callback.enqueue(new Callback<List<Truyen>>() {
            @Override
            public void onResponse(Call<List<Truyen>> call, Response<List<Truyen>> response) {
                progressBar.setVisibility(View.VISIBLE);
                ArrayList<Truyen> arrayList = (ArrayList<Truyen>) response.body();
                if (arrayList == null || arrayList.isEmpty() ){
                    progressBar.setVisibility(View.GONE);
                    checkMaxList = false;
                }
                arrayList1.addAll(arrayList);
                if (arrayList1.size() <= 21){
                    progressBar.setVisibility(View.GONE);
                }
                adapter = new TaleCategoryAdapter(ListTaleActivity.this,arrayList1);
                GridLayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(),3,RecyclerView.VERTICAL,false);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(gridLayoutManager);
                gridLayoutManager.scrollToPositionWithOffset(0, 0);
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<Truyen>> call, Throwable t) {
            }
        });
    }
}