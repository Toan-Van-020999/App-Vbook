package com.example.test_btl.service;

public class APIService {

    public static String url ="http://10.0.2.2//btl_mobile/";

    public static  Dataservice getService(){
        return  APIRetrofitClient.getClient(url).create(Dataservice.class);

    }
}
