package com.example.test_btl.adapter.thuvien;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.test_btl.R;
import com.example.test_btl.model.Truyen;

import java.util.List;

public class TruyenDeCuAdapter extends BaseAdapter {
    private Context context;
    private int layout;
    private List<Truyen> list;

    public TruyenDeCuAdapter(Context context, int layout, List<Truyen> list) {
        this.context = context;
        this.layout = layout;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public class ViewHolder{
        ImageView img;
        TextView tenTruyen,tenTacGia,trangthai;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = new ViewHolder();
        if(convertView == null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(layout,null);
            holder.tenTruyen =convertView.findViewById(R.id.tenTruyen);
            holder.tenTacGia = convertView.findViewById(R.id.tacgia);
            holder.trangthai = convertView.findViewById(R.id.trangthainomination);
            holder.img = convertView.findViewById(R.id.imageViewNomination);
            convertView.setTag(holder);
        }else{
            holder= (ViewHolder) convertView.getTag();
        }
        Truyen truyen = list.get(position);
        holder.tenTruyen.setText(truyen.getTen());
        holder.tenTacGia.setText("Tác giả: "+truyen.getTacgia());
        holder.trangthai.setText("Trang thái: " + truyen.getTrangthai());
        Glide.with(context).load(truyen.getAnh()).into(holder.img);
        return convertView;
    }
}
