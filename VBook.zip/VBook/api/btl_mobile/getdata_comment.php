<?php
	require "connect_btl.php";
	$id_truyen = $_GET['id_truyen'];
	$Query = "SELECT usercommenttruyen.*,user.taikhoan,user.image FROM user,usercommenttruyen Where usercommenttruyen.id_truyen = '$id_truyen' AND usercommenttruyen.iduser = user.id ORDER BY thoigian DESC";
	$data = mysqli_query($con,$Query);
	class Comment{
		function Comment($id,$iduser,$id_truyen,$noidung,$thoigian,$taikhoan,$image){
			$this -> Id = $id;
			$this -> Iduser = $iduser;
			$this -> Id_truyen = $id_truyen;
			$this -> Noidung = $noidung;
			$this -> Thoigian = $thoigian;
			$this -> Taikhoan = $taikhoan;
			$this -> Image = $image;

		}
	}
	$array = array();
	while ($row = mysqli_fetch_assoc($data)) {
		# code...
		array_push($array,new Comment($row['id'],$row['iduser'],$row['id_truyen'],$row['noidung'],$row['thoigian'],$row['taikhoan'],$row['image']) );
	}
	echo json_encode($array);
?>