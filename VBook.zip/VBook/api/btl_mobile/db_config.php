<?php

	$HOST = "localhost";
	$USER = "root";
	$PASSWORD = "";
	$DB_NAME = "android_tutorials";

?>