<?php
	require "connect_btl.php";
	if(isset($_POST['iduser']) && isset($_POST['id_truyen'])){
		$iduser = $_POST['iduser'];
		$id_truyen = $_POST['id_truyen'];
	}
	$query = "INSERT INTO userlovetruyen(iduser,id_truyen) VALUES ('$iduser','$id_truyen') ";
	
?>