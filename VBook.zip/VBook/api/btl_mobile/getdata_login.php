<?php
 	require "connect_btl.php";
 	if (isset($_POST['username']) && isset($_POST['password']) ) {
 		$username = $_POST['username'];
 		$password = $_POST['password'];
 	 	# code...
 	 } 
 	$query = "SELECT * FROM account WHERE taikhoan = '$username' AND matkhau = '$password' ";

 	$data = mysqli_query($con,$query);
 	Class Account{
 		function Account($id,$username,$password,$image){
 			$this -> Id = $id;
 			$this -> Username = $username;
 			$this -> Password = $password;
 			 $this -> Image = $image;
 		}

 	}
	$row = mysqli_fetch_assoc($data);
	 $account = new Account($row['id'],$row['taikhoan'],$row['matkhau'],$row['image']);
 	echo json_encode($account);
?>