<?php
	require "connect_btl.php";
	$query = "SELECT truyen.*, COUNT(*) AS luottheodoi FROM truyen,userfollowtruyen WHERE truyen.id = userfollowtruyen.id_truyen GROUP BY id_truyen ORDER BY luottheodoi DESC ";
	require "tale.php";
?>