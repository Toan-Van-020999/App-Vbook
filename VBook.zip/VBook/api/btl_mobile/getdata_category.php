<?php
	require "connect_btl.php";
	$query = "SELECT * FROM theloai ";
	$data = mysqli_query($con,$query);

	class Category{
		function Category($id,$ten,$alias){
			$this -> Id = $id;
			$this -> Ten = $ten;
			$this -> Alias = $alias;
			

		}
	}
	$array = array();
	while ($row = mysqli_fetch_assoc($data)) {
		# code...
		array_push($array,new Category($row['id'],$row['ten'],$row['alias']));
	}
	echo json_encode($array);
?>