<?php
	require "connect_btl.php";
	$query = "SELECT DISTINCT * FROM truyen WHERE trangthai = 'Hoàn Thành'";
	require "tale.php";
?>