<?php
	require "connect_btl.php";
	$iduser = $_GET['idaccount'];
	$query = "SELECT DISTINCT truyen.* FROM truyen,usercommenttruyen,user WHERE user.id = usercommenttruyen.iduser AND user.id = $iduser AND usercommenttruyen.id_truyen = truyen.id";
	require "tale.php ";
?>