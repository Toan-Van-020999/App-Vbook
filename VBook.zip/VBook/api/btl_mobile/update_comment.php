<?php
	require "connect_btl.php";
	$iduser = $_POST['iduser'];
	$id_truyen = $_POST['id_truyen'];
	$noidung = $_POST['noidung'];
	$thoigian = $_POST['thoigian'];

	$Query = "INSERT INTO usercommenttruyen SET id = NULL,iduser = '$iduser',id_truyen = '$id_truyen',noidung = '$noidung',thoigian = '$thoigian'";
	$data = mysqli_query($con,$Query);
		if($data){
			echo "OK";	
		}else{
			echo "FALD";
		}
?>