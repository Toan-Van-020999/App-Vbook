<?php
	require "connect_btl.php";
	
		# code...
	$iduser = $_POST['iduser'];
	$id_truyen = $_POST['id_truyen'];
	$tick = $_POST['tick'];
	
	if (strcmp ($tick ,'1') == 0) {
		# code...
		$Query = "INSERT INTO usernominationstruyen(iduser,id_truyen) VALUES ('$iduser','$id_truyen') ";
	}else {
		$Query = "DELETE FROM usernominationstruyen WHERE iduser = '$iduser' AND id_truyen = '$id_truyen' ";
	}

		// echo $Query;exit();
	 $data = mysqli_query($con,$Query);
	  if($data){
	 	echo "OK";
	 }else{
	 	echo "Faild";
	 }

	 

?>