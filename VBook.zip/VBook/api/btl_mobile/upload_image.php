<?php

	include 'connect_btl.php';


	$encodedImage = $_POST['EN_IMAGE'];

	$imageTitle = "myImage";
	$imageLocation = "images/$imageTitle.jpg";

	$sqlQuery = "INSERT INTO `images`(`title`, `location`) VALUES ('$imageTitle', '$imageLocation')";

	mysqli_query($con, $sqlQuery);
	if(mysqli_query($con, $sqlQuery)){

		file_put_contents($imageLocation, base64_decode($encodedImage));//put image to file images

		$result["status"] = TRUE;
		$result["remarks"] = "Image Uploaded Successfully";
		// echo $imageLocation;

	}else{

		$result["status"] = FALSE;
		$result["remarks"] = "Image Uploading Failed";

	}

	mysqli_close($con);

	print(json_encode($result));

?>