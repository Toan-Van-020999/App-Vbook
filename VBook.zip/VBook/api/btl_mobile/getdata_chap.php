<?php
	require "connect_btl.php";
	$id_truyen = $_GET['id_truyen'];
	$tick = $_GET['tick'];
	$query = "SELECT * FROM chap WHERE id_truyen = '$id_truyen' ORDER BY id ASC LIMIT $tick ";//tick nay la int
	$data = mysqli_query($con,$query);
	class Chap{
		function Chap($id,$tenchap,$noidung,$id_truyen){
			$this -> Id = $id;
			$this -> Tenchap = $tenchap;
			$this -> Noidung = $noidung;
			$this -> IdTruyen = $id_truyen;
		

		}
	}

	$array = array();
	while ($row = mysqli_fetch_assoc($data)) {
		# code...
		array_push($array,new Chap($row['id'],$row['tenchap'],$row['noidung'],$row['id_truyen']));
	}
	$tick-=1;
	echo json_encode($array[$tick]);
	//m tra ve 1 object. nhung cai afre  dm cai cai loi nay co ma cho cho nhu vay, t tra ve list chi co 1 object co dc k m. dc
?>