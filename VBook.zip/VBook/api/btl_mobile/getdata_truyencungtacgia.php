<?php
	require "connect_btl.php";
	$query = 'SELECT * FROM truyen Where tacgia = "'.$_GET['tacgia'].'" AND id != "'.$_GET['id'].'"  LIMIT 10';
	require "tale.php";
?>