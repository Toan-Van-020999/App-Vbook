<?php
	require "connect_btl.php";
	$iduser = $_GET['idaccount'];
	$query = "SELECT DISTINCT * FROM truyen WHERE iduser = $iduser";
	require "tale.php ";
?>