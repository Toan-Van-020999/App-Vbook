<?php
	$data = mysqli_query($con,$query);
	class Tale{
		function Tale($id,$ten,$anh,$tacgia,$chuong,$id_theloai,$trangthai,$gioithieu,$iduser){
			$this -> Id = $id;
			$this -> Ten = $ten;
			$this -> Anh = $anh;
			$this -> Tacgia = $tacgia;
			$this -> Chuong = $chuong;
			$this -> Id_theloai = $id_theloai;
			$this -> Trangthai = $trangthai;
			$this -> Gioithieu = $gioithieu;
			$this -> Iduser = $iduser;


		}
	}
	$array = array();
	while ($row = mysqli_fetch_assoc($data)) {
		# code...
		array_push($array,new Tale($row['id'],$row['ten'],$row['anh'],$row['tacgia'],$row['chuong'],$row['id_theloai'],$row['trangthai'],$row['gioithieu'],$row['iduser'] ));

	}

	echo json_encode($array);
?>