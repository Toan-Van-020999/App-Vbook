<?php
	require "connect_btl.php";
	$query = "SELECT * FROM truyen ORDER BY truyen.id DESC limit 20";
	require "tale.php";

?>