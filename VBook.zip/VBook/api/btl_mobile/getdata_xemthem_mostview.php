<?php
	require "connect_btl.php";
	$offset = $_GET['offset'];
	$query = "SELECT truyen.* FROM userviewtruyen,truyen WHERE truyen.id = userviewtruyen.id_truyen  ORDER BY countview DESC limit $offset,21";
	require "tale.php";

?>