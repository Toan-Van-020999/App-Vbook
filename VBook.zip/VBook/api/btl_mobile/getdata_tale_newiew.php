<?php
	require "connect_btl.php";
	$iduser = $_GET['idaccount'];
	$query = "SELECT truyen.* FROM user,truyen,userviewtruyen WHERE user.id = userviewtruyen.iduser AND truyen.id = userviewtruyen.id_truyen AND user.id = $iduser ORDER BY userviewtruyen.id DESC";
	require "tale.php";

?>