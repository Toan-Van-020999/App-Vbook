<?php
	require "connect_btl.php";
	$id = $_GET['id'];
	$query = "SELECT userviewtruyen.countview FROM userviewtruyen WHERE id_truyen = '$id' ";
	$data = mysqli_query($con,$query);
	$row = mysqli_fetch_assoc($data);

	$countview = $row['countview'];
	echo $countview;

?>