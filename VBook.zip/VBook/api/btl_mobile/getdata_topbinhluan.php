<?php
	require "connect_btl.php";
	$query = "SELECT truyen.*, COUNT(*) AS luotbinhluan FROM truyen,usercommenttruyen WHERE truyen.id = usercommenttruyen.id_truyen GROUP BY id_truyen ORDER BY luotbinhluan DESC";
	require "tale.php";
?>