<?php
// require 'connect_btl.php';
// $taikhoan = $_POST['taikhoan'];
// $matkhau = $_POST['matkhau'];

// $query = "INSERT INTO user(taikhoan,matkhau) VALUES ('$taikhoan','$matkhau') ";
// mysqli_query($con,$query);

require 'vendor/autoload.php';
use Kreait\Firebase\Factory;
// $token = 'eVOjaoHgRXe4-OXKCKBgvQ:APA91bF9XtccQ_4l2rkGSdXSeR9L17SWNy_BsLY6hYA9QdoPFQgiANKVGmTFaWJrLMFWzD78YEXuE2PllZqkdwe90Ia33Gx5NiGXUT0kOrT-7l9D6Pmu0PzXZnTWoD5dVXT-bvx_MT2m';
$factory = (new Factory)
    ->withServiceAccount('C:\xampp\htdocs\btl_mobile\baitaplonmobile-fd2d0-firebase-adminsdk-ygnmt-59813c4ca9.json');
$messaging = $factory->createMessaging();

$messaging->send(
	array(
		'notification' => array(
			'title' => 'demo',
			'body' => 'body',	

		),
		// 'token' => $token,
			'topic' => 'abcde',
	)
);

?>