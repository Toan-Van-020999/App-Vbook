<?php
	require "connect_btl.php";
	$query = 'UPDATE truyen SET luotyeuthich = luotyeuthich + 1 WHERE id = "'.$_GET['id']'"  ';
?>