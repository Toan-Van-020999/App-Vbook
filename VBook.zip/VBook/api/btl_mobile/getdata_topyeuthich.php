<?php
	require "connect_btl.php";
	$query = "SELECT truyen.*, COUNT(*) AS luotyeuthich FROM truyen,userlovetruyen WHERE truyen.id = userlovetruyen.id_truyen GROUP BY id_truyen ORDER BY luotyeuthich DESC";
	require "tale.php";
?>