<?php
	require "connect_btl.php";
	$id_truyen = $_POST['id_truyen'];
	$idUser = $_POST['idUser'];

	$Check = "SELECT id FROM userviewtruyen Where id_truyen = '$id_truyen' ";
	$dataCheck = mysqli_query($con,$Check);
	 

 	if($row = mysqli_fetch_assoc($dataCheck) != null){
 		$Query = "UPDATE userviewtruyen SET countview = countview + 1 WHERE id_truyen = '$id_truyen' ";
 	}else{
 		$Query = "INSERT INTO userviewtruyen(iduser,id_truyen,countview) VALUES ('$idUser','$id_truyen','1') " ; 
 	}
 	
 	$data = mysqli_query($con,$Query);
 	if($data){
 		echo "OK";
 	}else{
 		echo "FAILD";
 	}
?>