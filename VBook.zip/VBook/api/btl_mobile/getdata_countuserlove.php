<?php
 	require "connect_btl.php";
 	if (isset($_GET['id_truyen'])) {
 		$id = $_GET['id_truyen'];
 	 } 
 	$query = "SELECT iduser,Count(*) AS demyeuthich FROM userlovetruyen WHERE id_truyen = '$id' ";

 	$data = mysqli_query($con,$query);

 	Class Count{
 		function Count($iduser,$count){
 			$this -> Iduser = $iduser;
 			$this -> Count = $count;
 		}
 	}

	$row = mysqli_fetch_assoc($data);
	 $count = new Count($row['iduser'],$row['demyeuthich'] );
 	echo json_encode($count);
?>