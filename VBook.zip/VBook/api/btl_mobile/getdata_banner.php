<?php
	require "connect_btl.php";
	$query = "SELECT DISTINCT * FROM truyen ORDER BY RAND (" . date("Ymd") . ") LIMIT 4";
	require "tale.php";


?>