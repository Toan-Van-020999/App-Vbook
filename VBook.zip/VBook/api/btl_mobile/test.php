<?php
require 'connect_btl.php';

// require 'vendor/autoload.php';
// use Kreait\Firebase\Factory;
// $token = 'eVOjaoHgRXe4-OXKCKBgvQ:APA91bF9XtccQ_4l2rkGSdXSeR9L17SWNy_BsLY6hYA9QdoPFQgiANKVGmTFaWJrLMFWzD78YEXuE2PllZqkdwe90Ia33Gx5NiGXUT0kOrT-7l9D6Pmu0PzXZnTWoD5dVXT-bvx_MT2m';

// $factory = (new Factory)
//     ->withServiceAccount('C:\xampp\htdocs\btl_mobile\fir-test-e084c-firebase-adminsdk-ia1os-47da388ccf.json');

// $messaging = $factory->createMessaging();

// $messaging->send(
// 	array(
// 		'notification' => array(
// 			'title' => 'demo',
// 			'body' => 'body',
// 			// 'clickAction'=>'MainActivity2'

// 		),
// 		// 'token' => $token,
// 		'topic' => 'abcde',
// 	)
// );

?>