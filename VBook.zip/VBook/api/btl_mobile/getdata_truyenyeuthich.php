<?php
	require "connect_btl.php";
	$iduser = $_GET['idaccount'];
	$query = "SELECT DISTINCT truyen.* FROM truyen,userlovetruyen,user WHERE user.id = userlovetruyen.iduser AND user.id = $iduser AND userlovetruyen.id_truyen = truyen.id";
	require "tale.php ";
?>