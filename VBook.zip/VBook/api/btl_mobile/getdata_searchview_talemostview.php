<?php
	require "connect_btl.php";
	$query = "SELECT truyen.* FROM userviewtruyen,truyen WHERE truyen.id = userviewtruyen.id_truyen  ORDER BY countview DESC ";
	require "tale.php";

?>