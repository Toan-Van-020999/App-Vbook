<?php
	require "connect_btl.php";
	$offset = $_GET['offset'];
	$query = "SELECT * FROM truyen limit $offset,21";
	require "tale.php";

?>