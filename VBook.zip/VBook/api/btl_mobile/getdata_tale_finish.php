<?php
	require "connect_btl.php";
	$query = "SELECT DISTINCT * FROM truyen Where trangthai = 'Hoàn Thành' ORDER BY RAND (" . date("Ymd") . ")  limit 8";
	require "tale.php";

?>