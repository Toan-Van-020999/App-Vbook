<?php
	require "connect_btl.php";
	$query = 'SELECT * FROM chap Where id_truyen = "'.$_GET['id'].'" ';
	$data = mysqli_query($con,$query);

	class Chap{
		function Chap($id,$tenchap,$noidung,$id_truyen){
			$this -> Id = $id;
			$this -> Tenchap = $tenchap;
			$this -> Noidung = $noidung;
			$this -> IdTruyen = $id_truyen;
			

		}
	}
	$arraybanner = array();
	while ($row = mysqli_fetch_assoc($data)) {
		# code...
		array_push($arraybanner,new Chap($row['id'],$row['tenchap'],$row['noidung'],$row['id_truyen']));
		
	}

	echo json_encode($arraybanner);
?>