<?php
	require "connect_btl.php";
	$offset = $_GET['offset'];
	$query = "SELECT truyen.* FROM chap,truyen WHERE chap.id_truyen = truyen.id GROUP BY chap.id_truyen ORDER BY id DESC limit $offset,21";
	require "tale.php";

?>