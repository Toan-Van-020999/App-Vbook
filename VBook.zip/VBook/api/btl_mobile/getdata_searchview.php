<?php
	require "connect_btl.php";
	$query = "SELECT * FROM truyen";
	require "tale.php";

?>