<?php
	require "connect_btl.php";
	$query = "SELECT truyen.* FROM chap,truyen WHERE chap.id_truyen = truyen.id GROUP BY chap.id_truyen ORDER BY id DESC limit 8";
	require "tale.php";

?>