<?php
	require "connect_btl.php";
	$query = 'SELECT * FROM truyen ';
	// tacgia = "'.$_GET['tacgia'].'" AND id != "'.$_GET['id'].'"  LIMIT 10'
	if (isset($_GET['trangthai']) || isset($_GET['idtheloai'])  || isset($_GET['chuong']) ) {
		# code...
		$query.='WHERE ';
	}
	
	if(isset($_GET['trangthai'])){
		$query .= 'trangthai=';
		$trangthai = $_GET['trangthai'];
		$query.="'$trangthai'";
	}
	
		
	if(isset($_GET['idtheloai'])){
		if(isset($_GET['trangthai'])){
			$query.=' AND ';
		}
		$query .= ' id_theloai IN ';
		$id_theloai = $_GET['idtheloai'];
		$query.="($id_theloai)";
	}


	if (isset($_GET['chuong']) ) {
		if (isset($_GET['trangthai']) || isset($_GET['idtheloai'])) {
			$query.=' AND ';
		}
		$query .= ' chuong ';
		if($_GET['chuong'] == 'Dưới 25'){
			$query .= '< 25';
		}
		else{
			$query .= '> 25';
		}
	}
	// echo $query;
	require "tale.php"; 
?>