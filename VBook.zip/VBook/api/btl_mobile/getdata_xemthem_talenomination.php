<?php
	require "connect_btl.php";
	$offset = $_GET['offset'];
	$query = "SELECT truyen.* FROM usernominationstruyen,truyen WHERE truyen.id = usernominationstruyen.id_truyen GROUP BY usernominationstruyen.id_truyen ORDER BY COUNT(usernominationstruyen.id_truyen) DESC limit $offset,21";
	require "tale.php";

?>