<?php
	require "connect_btl.php";
	$iduser = $_GET['idaccount'];
	$query = "SELECT DISTINCT truyen.* FROM truyen,user,userfollowtruyen WHERE user.id = userfollowtruyen.iduser AND userfollowtruyen.id_truyen = truyen.id AND user.id = $iduser ";
	require "tale.php";

?>