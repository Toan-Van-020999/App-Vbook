<?php
	require "connect_btl.php";
	$query = 'SELECT * FROM truyen Where id_theloai = "'.$_GET['id'].'" ';
	require "tale.php";

?>