<?php

	include 'connect_btl.php';



	$encodedImage = $_POST['EN_IMAGE'];
	$idUser = $_POST['ID_USER'];

	$imageTitle = "imageUser";
	$imageLocation = "images/$imageTitle$idUser.jpg";

	$sqlQuery = "UPDATE user SET  image = '$imageLocation' WHERE id = '$idUser'  ";
	// echo $sqlQuery;exit();

	mysqli_query($con, $sqlQuery);

	file_put_contents($imageLocation, base64_decode($encodedImage));

	echo json_encode($imageLocation);

?>