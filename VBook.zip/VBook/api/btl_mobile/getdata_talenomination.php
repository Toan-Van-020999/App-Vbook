<?php
	require "connect_btl.php";
	$query = "SELECT truyen.* FROM usernominationstruyen,truyen WHERE truyen.id = usernominationstruyen.id_truyen GROUP BY usernominationstruyen.id_truyen ORDER BY COUNT(usernominationstruyen.id_truyen) DESC limit 4";
	require "tale.php";

?>