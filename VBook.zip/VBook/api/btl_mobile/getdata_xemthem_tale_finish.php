<?php
	require "connect_btl.php";
	$offset = $_GET['offset'];
	$query = "SELECT DISTINCT * FROM truyen WHERE trangthai = 'Hoàn Thành' limit $offset,21";
	require "tale.php";

?>