<?php
	require "connect_btl.php";
	$query = "SELECT truyen.* FROM truyen,userviewtruyen WHERE truyen.id = userviewtruyen.id_truyen  ORDER BY countview DESC ";
	require "tale.php";
?>